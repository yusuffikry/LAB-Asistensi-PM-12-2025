package com.example.tuprak6;

public class Character {
    private int id;
    private String name;
    private String status;
    private String species;
    private String gender;
    private String image;

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getStatus() {
        return status;
    }

    public String getSpecies() {
        return species;
    }

    public String getGender() {
        return gender;
    }

    public String getImage() {
        return image;
    }
}
