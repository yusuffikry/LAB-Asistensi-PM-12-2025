package com.example.tuprak4_h071231010;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class DataGenerator {
    public static List<Book> bookList = new ArrayList<>();

    public static List<Book> generateDummyBooks() {
        if (!bookList.isEmpty()) return bookList;

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "The Alpha Girl's Guide",
                "Henry Manampiring",
                2020,
                "The Alpha Girl’s Guide adalah buku motivasi untuk perempuan muda agar menjadi pribadi yang mandiri, percaya diri, dan tidak bergantung pada validasi orang lain, dengan fokus pada pengembangan diri dan hubungan yang sehat.",
                "android.resource://com.example.tuprak4_h071231010/drawable/b1",
                "Self-Help",
                4.7f,
                " Walaupun ditulis oleh pria, buku ini menunjukkan empati terhadap isu-isu yang dihadapi perempuan dan menyampaikannya tanpa menggurui."
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "The Architecture of Love",
                "Ika Natassa",
                2016,
                "Kisah penulis bernama Raia yang menemukan cinta dan makna hidup di New York bersama arsitek misterius, River.",
                "android.resource://com.example.tuprak4_h071231010/drawable/b2",
                "Romance",
                4.1f,
                "Romantis, emosional, dan menyentuh, dengan latar kota New York yang memikat."
        ));

        // Add 13 more books with different genres
        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "Serangkai",
                "Valerie Patkar",
                2020,
                "Tentang empat sahabat dengan luka batin masing-masing yang mencoba bertahan dan pulih bersama.",
                "android.resource://com.example.tuprak4_h071231010/drawable/b3",
                "Fiction",
                4.3f,
                "Chillingly prophetic and thought-provoking."
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "Garis Waktu",
                "Fiersa Besari",
                2016,
                "Kumpulan prosa dan puisi tentang cinta, kehilangan, dan proses menemukan diri sendiri.",
                "android.resource://com.example.tuprak4_h071231010/drawable/b4",
                "Puisi/Prosa Liris",
                4.3f,
                "Puitis dan penuh perasaan, cocok untuk yang menyukai renungan tentang cinta dan hidup."
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "Moon",
                "Tere Liye",
                2021,
                " Petualangan Moon, anak berbakat, dalam dunia fantasi penuh makna dan tantangan.",
                "android.resource://com.example.tuprak4_h071231010/drawable/b5",
                "Fiction",
                4.3f,
                "Seru dan imajinatif, dengan pesan moral tentang keberanian dan integritas."
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "Negeri 5 Menara",
                "A. Fuadi",
                2009,
                "Kisah kehidupan santri di pesantren modern dengan impian tinggi dan semangat “Man Jadda Wajada.”",
                "android.resource://com.example.tuprak4_h071231010/drawable/b6",
                "Fiksi/Pendidikan",
                4.6f,
                "sebagai orang yang sulit untuk memulai membaca buku-buku non-fiksi sejarah, buku ini sangat membantu anak-anak muda indonesia dalam mempelajari sejarah yang minim sensor.\n" +
                        "melalui buku ini, aku sadar kalau ternyata selama ini, buku-buku sejarah resmi yang diajarkan di sekolah-sekolah didistorsi sedemikian rupa untuk kepentingan rezim."
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "ILY",
                "Tere Liye",
                2022,
                "Kisah cinta remaja yang dibalut misteri dan teka-teki masa lalu.",
                "android.resource://com.example.tuprak4_h071231010/drawable/b9",
                "Romance",
                4.8f,
                "Ringan tapi menyentuh, dengan twist khas Tere Liye yang membuat penasaran."
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "Insecurity",
                "Alvi Syahrin",
                2021,
                " Buku motivasi untuk menghadapi rasa tidak percaya diri dan membangun penerimaan diri.",
                "android.resource://com.example.tuprak4_h071231010/drawable/b8",
                "Fantasy",
                4.7f,
                "Menenangkan dan relatable, cocok untuk generasi muda yang sedang mencari jati diri."
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "Laut Bercerita",
                "Leila S. Chudori",
                2017,
                "Mengangkat kisah aktivis yang hilang di masa Orde Baru, dilihat dari sisi keluarga dan sahabat.",
                "android.resource://com.example.tuprak4_h071231010/drawable/b7",
                "Fiksi Sejarah",
                4.5f,
                "Emosional dan kuat, menyentuh isu HAM dengan narasi mendalam."
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "Bandung After Rain",
                "Wulan Nur Amalia",
                2018,
                "Kumpulan puisi dan prosa tentang cinta, rindu, dan kehilangan berlatar Bandung yang penuh kenangan.",
                "android.resource://com.example.tuprak4_h071231010/drawable/b10",
                "Puisi",
                4.2f,
                "Puitis dan melankolis, cocok untuk pembaca yang sedang mengenang masa lalu."
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "Geez & Ann",
                "Rintik Sedu",
                2018,
                "Kisah cinta dua karakter dengan latar belakang berbeda yang diuji oleh waktu dan jarak.",
                "android.resource://com.example.tuprak4_h071231010/drawable/b11",
                "Romance",
                4.7f,
                "Romantis dan sederhana, dengan dialog khas anak muda yang dekat dengan realita."
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "Filosofi Teras",
                "Henry Manampiring",
                2018,
                "Pengenalan filsafat Stoikisme untuk mengelola emosi dan menjalani hidup lebih tenang.",
                "android.resource://com.example.tuprak4_h071231010/drawable/b12",
                "Self-help / Filsafat Populer",
                4.6f,
                "Mencerahkan dan aplikatif, cocok untuk pembaca yang ingin hidup lebih rasional dan damai."
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "Arah Kembali",
                "Langit Ubiratna",
                2020,
                "Cerita cinta dan pencarian makna hidup yang mengajak pembaca untuk kembali pada jati diri.",
                "android.resource://com.example.tuprak4_h071231010/drawable/b13",
                "Romance",
                4.1f,
                "Menenangkan dan puitis, penuh pesan filosofis yang dalam."
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "3726 MDPL",
                "Nurwina Sari",
                2021,
                "Perjalanan mendaki gunung yang menjadi metafora pencarian jati diri dan melawan trauma.",
                "android.resource://com.example.tuprak4_h071231010/drawable/b14",
                "Fiction/Petualangan",
                3.2f,
                "Menegangkan dan reflektif, menggambarkan perjuangan fisik dan mental dengan apik."
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "Tenggelamnya Kapal Van Der Wijck",
                "Buya Hamka",
                1938,
                "Kisah cinta tragis Zainuddin dan Hayati yang terhalang adat dan status sosial.",
                "android.resource://com.example.tuprak4_h071231010/drawable/b15",
                "Fiksi Klasi/Romance",
                4.2f,
                "Klasik dan menyayat hati, sarat kritik sosial dan keindahan bahasa sastra Melayu."
        ));


        return bookList;
    }
}
