package com.example.tuprak4_h071231010;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.tuprak4_h071231010.R;
import com.example.tuprak4_h071231010.Book;
import com.example.tuprak4_h071231010.DataGenerator;

import java.util.List;

public class DetailActivity extends AppCompatActivity {
    private ImageView ivCover, ivLike;
    private TextView tvTitle, tvAuthor, tvYear, tvBlurb, tvGenre, tvRating, tvReview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // Initialize views
        ivCover = findViewById(R.id.iv_cover);
        ivLike = findViewById(R.id.iv_like);
        tvTitle = findViewById(R.id.tv_title);
        tvAuthor = findViewById(R.id.tv_author);
        tvYear = findViewById(R.id.tv_year);
        tvBlurb = findViewById(R.id.tv_blurb);
        tvGenre = findViewById(R.id.tv_genre);
        tvRating = findViewById(R.id.tv_rating);
        tvReview = findViewById(R.id.tv_review);

        String bookId = getIntent().getStringExtra("BOOK_ID");
        Book book = findBookById(bookId);

        if (book != null) {
            displayBookDetails(book);
            setupLikeButton(book);
        } else {
            Toast.makeText(this, "Book not found", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private Book findBookById(String bookId) {
        for (Book book : DataGenerator.bookList) {
            if (book.getId().equals(bookId)) {
                return book;
            }
        }
        return null;
    }

    private void displayBookDetails(Book book) {
        tvTitle.setText(book.getTitle());
        tvAuthor.setText(book.getAuthor());
        tvYear.setText(String.valueOf(book.getYear()));
        tvBlurb.setText(book.getBlurb());
        tvGenre.setText(book.getGenre());
        tvRating.setText(String.format("Rating: %.1f/5", book.getRating()));
        tvReview.setText(book.getReview());

        if (book.getImageUri() != null && !book.getImageUri().isEmpty()) {
            Glide.with(this)
                    .load(book.getImageUri())
                    .placeholder(R.drawable.b1)
                    .into(ivCover);
        } else {
            ivCover.setImageResource(R.drawable.b1);
        }

        ivLike.setImageResource(book.isLiked() ? R.drawable.liked : R.drawable.like);
    }

    private void setupLikeButton(Book book) {
        ivLike.setOnClickListener(v -> {
            book.setLiked(!book.isLiked());
            ivLike.setImageResource(book.isLiked() ? R.drawable.liked : R.drawable.like);

            if (book.isLiked()) {
                Toast.makeText(this, "Added to favorites", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
