package com.example.tuprak2_h071231010;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class EditProfileActivity extends AppCompatActivity {

    private ImageView profileImage;
    private EditText editName;
    private Button saveButton;
    private Uri selectedImageUri = null;

    private final ActivityResultLauncher<Intent> pickImageLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    selectedImageUri = result.getData().getData();
                    if (selectedImageUri != null) {
                        profileImage.setImageURI(selectedImageUri);
                    }
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        profileImage = findViewById(R.id.imageProfile);
        editName = findViewById(R.id.inputNama);
        saveButton = findViewById(R.id.button_save);

        // Ambil data dari intent
        Intent intent = getIntent();
        if (intent != null) {
            String nama = intent.getStringExtra("nama");
            if (nama != null) {
                editName.setText(nama);
            }

            String imageUriStr = intent.getStringExtra("imageUri");
            if (imageUriStr != null) {
                selectedImageUri = Uri.parse(imageUriStr);
                profileImage.setImageURI(selectedImageUri);
            } else {
                profileImage.setImageResource(R.drawable.pict1); // default image
            }
        }

        // Klik gambar untuk ganti profil
        profileImage.setOnClickListener(v -> {
            Intent pickImage = new Intent(Intent.ACTION_GET_CONTENT);
            pickImage.setType("image/*");
            pickImageLauncher.launch(pickImage);
        });

        // Tombol Simpan
        saveButton.setOnClickListener(v -> {
            String updatedName = editName.getText().toString();
            Intent resultIntent = new Intent();
            resultIntent.putExtra("nama", updatedName);
            if (selectedImageUri != null) {
                resultIntent.putExtra("imageUri", selectedImageUri.toString());
            }
            setResult(RESULT_OK, resultIntent);
            finish(); // kembali ke MainActivity
        });
    }
}
