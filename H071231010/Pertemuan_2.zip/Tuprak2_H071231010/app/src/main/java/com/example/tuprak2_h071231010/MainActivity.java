package com.example.tuprak2_h071231010;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView textNama;
    private ImageView profileImageView;

    private final ActivityResultLauncher<Intent> editProfileLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    // Ambil data yang dikirim dari EditProfileActivity
                    String updatedNama = result.getData().getStringExtra("nama");
                    String imageUriString = result.getData().getStringExtra("imageUri");
                    if (imageUriString != null) {
                        Uri updatedImageUri = Uri.parse(imageUriString);
                        profileImageView.setImageURI(updatedImageUri);
                    }


                    if (updatedNama != null) {
                        textNama.setText(updatedNama);
                    }
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textNama = findViewById(R.id.textNama);
        profileImageView = findViewById(R.id.profileImage); // Pastikan ID ini sesuai XML kamu
        ImageView editButton = findViewById(R.id.editProfileIcon);

        // Cek jika activity dipanggil dengan data
        UserData userData = getIntent().getParcelableExtra("extra_userdata");
        if (userData != null) {
            textNama.setText(userData.getNama());

            Uri imageUri = userData.getImageUri();
            if (imageUri != null) {
                profileImageView.setImageURI(imageUri);
            }
        }

        // Aksi saat tombol edit diklik
        editButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EditProfileActivity.class);
            intent.putExtra("nama", textNama.getText().toString());
            // Kalau mau kirim imageUri juga bisa ditambah di sini
            editProfileLauncher.launch(intent);
        });
    }
}
