package com.example.praktikum3;

import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserStaticData {
    private static final Map<String, User> users = new HashMap<>();
    static final Map<String, List<Feed>> userPosts = new HashMap<>();
    private static final Map<String, List<List<Integer>>> userHighlights = new HashMap<>();


    static {

        users.put("login", new User(
                "login",
                "Indyyyy",
                "ii",
                "Tinky Winky",
                String.valueOf(R.drawable.ii),
                2,
                "1",
                "1"
        ));
        List<Feed> postsLogin = new ArrayList<>();
        postsLogin.add(new Feed(R.drawable.ii, R.drawable.i1, "Indyyyy", "10", "1", "0", "login", "Indyyyy", "it's me", "", false)); // imagePost berupa Integer (resource ID)
        postsLogin.add(new Feed(R.drawable.ii, R.drawable.i2, "Indyyyy", "10", "3", "-", "login", "Indyyyy", ":)", "", false)); // imagePost berupa Integer (resource ID)

        Log.d("UserStaticData", "User1 Posts: " + postsLogin);
        userPosts.put("login", postsLogin);

        List<List<Integer>> highlightsLogin = new ArrayList<>();
        List<Integer> highlightLogin1 = new ArrayList<>();
        highlightLogin1.add(R.drawable.i3);
        highlightLogin1.add(R.drawable.i4);

        List<Integer> highlightLogin2 = new ArrayList<>();
        highlightLogin2.add(R.drawable.i5);

        highlightsLogin.add(highlightLogin1);
        highlightsLogin.add(highlightLogin2);

        userHighlights.put("login", highlightsLogin);

        users.put("user1", new User(
                "user1",
                "Zayyyy",
                "Zakiyyah",
                "Dipsy",
                String.valueOf(R.drawable.zz),
                2,
                "100",
                "1"
        ));
        List<Feed> postsUser1 = new ArrayList<>();
        postsUser1.add(new Feed(R.drawable.zz, R.drawable.z1, "Zayyyy", "3k", "65", "5", "user1", "Zayyyy", "nyamnyam...", "", false));
        postsUser1.add(new Feed(R.drawable.zz, R.drawable.z3, "Zayyyy", "223", "76", "87", "user1", "Zayyyy", "sisfo", "", false));
        Log.d("UserStaticData", "User1 Posts: " + postsUser1);
        userPosts.put("user1", postsUser1);

        List<List<Integer>> highlightsUser1 = new ArrayList<>();
        List<Integer> highlightsUser1_1 = new ArrayList<>();
        highlightsUser1_1.add(R.drawable.z2);
        highlightsUser1_1.add(R.drawable.z4);
        highlightsUser1.add(highlightsUser1_1);
        userHighlights.put("user1", highlightsUser1);

        users.put("user2", new User(
                "user2",
                "Syyyy",
                "Sisy",
                "Lala",
                String.valueOf(R.drawable.ss),
                2,
                "100",
                "1"
        ));
        List<Feed> postsUser2 = new ArrayList<>();
        postsUser2.add(new Feed(R.drawable.ss, R.drawable.s5, "Syyyy", "5k", "20", "2", "user2", "Syyyy", "Bukber Sisfo23", "", false)); // imagePost berupa Integer (resource ID)
        postsUser2.add(new Feed(R.drawable.ss, R.drawable.s2, "Syyyy", "6k", "777", "50", "user2", "Syyyy", "Lab Mobile", "", false)); // imagePost berupa Integer (resource ID)
        Log.d("UserStaticData", "User2 Posts: " + postsUser2);
        userPosts.put("user2", postsUser2);

        List<List<Integer>> highlightsUser2 = new ArrayList<>();
        List<Integer> highlightsUser2_1 = new ArrayList<>();
        highlightsUser2_1.add(R.drawable.s4);
        highlightsUser2_1.add(R.drawable.s3);
        highlightsUser2_1.add(R.drawable.s6);
        highlightsUser2.add(highlightsUser2_1);
        userHighlights.put("user2", highlightsUser2);

        users.put("user4", new User(
                "user4",
                "Nayyyy",
                "Nayla",
                "Poo",
                String.valueOf(R.drawable.nn),
                3,
                "100",
                "1"
        ));
        List<Feed> postsUser4 = new ArrayList<>();
        postsUser4.add(new Feed(R.drawable.nn, R.drawable.n1, "Nayyyy", "1k", "150", "0", "user4", "Nayyyy", "Luvvvv", "", false)); // imagePost berupa Integer (resource ID)
        postsUser4.add(new Feed(R.drawable.nn, R.drawable.n3, "Nayyyy", "2k", "500", "0", "user4", "Nayyyy", ":<3", "", false)); // imagePost berupa Integer (resource ID)
        postsUser4.add(new Feed(R.drawable.nn, R.drawable.n5, "Nayyyy", "3k", "50", "0", "user4", "Nayyyy", "sisfo", "", false)); // imagePost berupa Integer (resource ID)
        Log.d("UserStaticData", "User2 Posts: " + postsUser2);
        userPosts.put("user4", postsUser4);

        List<List<Integer>> highlightsUser4 = new ArrayList<>();
        List<Integer> highlightsUser4_1 = new ArrayList<>();
        highlightsUser4_1.add(R.drawable.n2);
        highlightsUser4_1.add(R.drawable.n4);
        highlightsUser4_1.add(R.drawable.n6);
        highlightsUser4.add(highlightsUser4_1);
        userHighlights.put("user4", highlightsUser4);



        Log.d("UserStaticData", "Initial userPosts: " + userPosts);
    }


    public static User getUser(String userId) {

        return users.get(userId);
    }
    public static List<Feed> getPosts(String userId) {

        return userPosts.get(userId);
    }
    public static List<List<Integer>> getHighlights(String userId) {

        return userHighlights.get(userId);
    }

}