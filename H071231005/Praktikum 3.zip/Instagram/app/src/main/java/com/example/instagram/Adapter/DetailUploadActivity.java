package com.example.instagram.Adapter;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.instagram.Models.Upload;
import com.example.instagram.R;

public class DetailUploadActivity extends AppCompatActivity {

    private ImageView imageView;
    private TextView captionTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_upload);

        imageView = findViewById(R.id.upload_detail);
        captionTextView = findViewById(R.id.caption_detail);

        Upload upload = getIntent().getParcelableExtra("upload");

        if (upload != null) {
            imageView.setImageURI(upload.getImageUri());
            captionTextView.setText(upload.getCaption());
        }
    }
}
