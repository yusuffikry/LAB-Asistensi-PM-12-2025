package com.example.instagram.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.instagram.R;

import java.util.List;

public class ImageFeedAdapter  extends RecyclerView.Adapter<ImageFeedAdapter.FeedViewHolder>{
    private List<Integer> recycle_highlight;
    private Context context;

    public ImageFeedAdapter(List<Integer> feedan, Context context) {
        this.recycle_highlight = feedan;
        this.context = context;
    }

    @NonNull
    @Override
    public ImageFeedAdapter.FeedViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_higlight, parent, false);
        return new ImageFeedAdapter.FeedViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ImageFeedAdapter.FeedViewHolder holder, int position) {
        int resId = recycle_highlight.get(position);
        holder.foto_highlight.setImageResource(resId);
    }

    @Override
    public int getItemCount() {
        return recycle_highlight.size();
    }

    public class FeedViewHolder extends RecyclerView.ViewHolder {
        ImageView foto_highlight;

        public FeedViewHolder(@NonNull View itemView) {
            super(itemView);
            foto_highlight = itemView.findViewById(R.id.foto_highlight);
        }
    }
}
