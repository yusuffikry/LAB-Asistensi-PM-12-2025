package com.example.instagram.Data;

import com.example.instagram.Models.Post;
import com.example.instagram.Models.Upload;
import com.example.instagram.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DataPost {

    public static ArrayList<Post> posts = generatePosts();
    public static List<Upload> uploadList = new ArrayList<>();

    private static ArrayList<Post> generatePosts() {
        ArrayList<Post> posts = new ArrayList<>();

        List<Integer> venuselly =new ArrayList<>();
        venuselly.add(R.drawable.image1);
        venuselly.add(R.drawable.image2);
        venuselly.add(R.drawable.image3);

        posts.add(new Post(
                R.drawable.image1,
                venuselly,
                "venuselly",
                "1.2M",
                "1.2K",
                "1.2K",
                "Caption 1",
                "100",
                "200",
                "300",
                "Venuselly",
                "Bio 1", venuselly, venuselly));

        return posts;
    }
}
