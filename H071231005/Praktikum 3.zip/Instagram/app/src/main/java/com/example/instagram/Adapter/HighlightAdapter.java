package com.example.instagram.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.instagram.HighlightUser;
import com.example.instagram.R;
import java.util.List;

public class HighlightAdapter extends RecyclerView.Adapter<HighlightAdapter.ViewHolder> {

    private Context context;
    private List<Integer> highlightList;

    public HighlightAdapter(Context context, List<Integer> highlightList) {
        this.context = context;
        this.highlightList = highlightList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_feed, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.highlight.setImageResource(highlightList.get(position));

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, HighlightUser.class);
            intent.putExtra("highlightList", highlightList.get(position));
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return highlightList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView highlight;

        public ViewHolder(View itemView) {
            super(itemView);
            highlight = itemView.findViewById(R.id.highlight);
        }
    }
}
