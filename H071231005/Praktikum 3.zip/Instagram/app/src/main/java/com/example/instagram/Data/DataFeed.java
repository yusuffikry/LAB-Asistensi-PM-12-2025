package com.example.instagram.Data;

import com.example.instagram.Models.Feed;
import com.example.instagram.Models.Post;
import com.example.instagram.R;

import java.util.ArrayList;
import java.util.List;

public class DataFeed {
    public static ArrayList<Feed> feeds = generateFeeds();

    private static ArrayList<Feed> generateFeeds() {

        List<Integer> feed1 = new ArrayList<>();
        feed1.add(R.drawable.image1);
        Feed feeds1 = new Feed(R.drawable.image1, "Meong", feed1);

        List<Integer> feed2 = new ArrayList<>();
        feed2.add(R.drawable.image2);
        Feed feeds2 = new Feed(R.drawable.image1, "Kucing", feed2);

        ArrayList<Feed> dump = new ArrayList<>();
        dump.add(feeds1);
        dump.add(feeds2);

        return dump;
    }

}
