package com.example.x;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int EDIT_PROFILE_REQUEST_CODE = 1;
    private ImageView profileImageView, coverImageView;
    private TextView nameTextView, bioTextView, websiteTextView, birthDateTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize TextViews
        nameTextView = findViewById(R.id.nameValueTextView);
        bioTextView = findViewById(R.id.bioTextView);
        websiteTextView = findViewById(R.id.websiteTextView);
        birthDateTextView = findViewById(R.id.birthDateTextView);

        // Initialize ImageViews
        profileImageView = findViewById(R.id.profileImageView);
        coverImageView = findViewById(R.id.coverImageView);

        // Load data from Intent
        loadProfileData();

        // Set up the "Edit Profile" button
        ActivityResultLauncher<Intent> editProfileLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            // Retrieve updated data from the Intent
                            String updatedName = data.getStringExtra("updatedName");
                            String updatedBio = data.getStringExtra("updatedBio");
                            String updatedWebsite = data.getStringExtra("updatedWebsite");
                            String updatedBirthDate = data.getStringExtra("updatedBirthDate");
                            String updatedProfileImageUri = data.getStringExtra("updatedProfileImageUri");
                            String updatedCoverImageUri = data.getStringExtra("updatedCoverImageUri");

                            // Update the UI with the new profile data
                            nameTextView.setText(updatedName);
                            bioTextView.setText(updatedBio);
                            websiteTextView.setText(updatedWebsite);
                            birthDateTextView.setText(updatedBirthDate);

                            // Load updated images
                            if (updatedProfileImageUri != null) {
                                Glide.with(this)
                                        .load(updatedProfileImageUri)
                                        .into(profileImageView);
                            }
                            if (updatedCoverImageUri != null) {
                                Glide.with(this)
                                        .load(updatedCoverImageUri)
                                        .into(coverImageView);
                            }
                        }
                    }
                });

        // "Edit Profile" button functionality
        Button editProfileButton = findViewById(R.id.editProfileButton);
        editProfileButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EditProfileActivity.class);

            // Pass current profile data to EditProfileActivity using putExtra
            intent.putExtra("currentName", nameTextView.getText().toString());
            intent.putExtra("currentBio", bioTextView.getText().toString());
            intent.putExtra("currentWebsite", websiteTextView.getText().toString());
            intent.putExtra("currentBirthDate", birthDateTextView.getText().toString());

            editProfileLauncher.launch(intent);  // Launch the EditProfileActivity
        });
    }

    // Function to load the profile data (This is to handle the initial data)
    private void loadProfileData() {
        Intent intent = getIntent();
        String storedName = intent.getStringExtra("userName");
        String storedBio = intent.getStringExtra("userBio");
        String storedWebsite = intent.getStringExtra("userWebsite");
        String storedBirthDate = intent.getStringExtra("userBirthDate");

        // Set the retrieved data into TextViews
        nameTextView.setText(storedName != null ? storedName : "Default Name");
        bioTextView.setText(storedBio != null ? storedBio : "Default Bio");
        websiteTextView.setText(storedWebsite != null ? storedWebsite : "Default Website");
        birthDateTextView.setText(storedBirthDate != null ? storedBirthDate : "Default BirthDate");

        // Load profile image if available
        String profileImageUri = intent.getStringExtra("profileImageUri");
        String coverImageUri = intent.getStringExtra("coverImageUri");

        if (profileImageUri != null) {
            Glide.with(this)
                    .load(profileImageUri)
                    .into(profileImageView);
        }
        if (coverImageUri != null) {
            Glide.with(this)
                    .load(coverImageUri)
                    .into(coverImageView);
        }
    }
}

