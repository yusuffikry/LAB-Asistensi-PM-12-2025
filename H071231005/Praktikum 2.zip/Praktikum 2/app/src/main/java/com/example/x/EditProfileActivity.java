package com.example.x;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

import java.util.Calendar;

import androidx.appcompat.app.AppCompatActivity;

public class EditProfileActivity extends AppCompatActivity {

    private EditText editTextName, editTextBio, editTextWebsite, editTextBirthDate;
    private ImageView profileImageView, coverImageView;
    private Uri profileImageUri, coverImageUri;
    private int year, month, day;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_profile);

        // Find EditText views
        editTextName = findViewById(R.id.nameEditText);
        editTextBio = findViewById(R.id.bioEditText);
        editTextWebsite = findViewById(R.id.websiteEditText);
        editTextBirthDate = findViewById(R.id.birthDateEditText);

        // Get data passed from MainActivity
        Intent intent = getIntent();
        String currentName = intent.getStringExtra("currentName");
        String currentBio = intent.getStringExtra("currentBio");
        String currentWebsite = intent.getStringExtra("currentWebsite");
        String currentBirthDate = intent.getStringExtra("currentBirthDate");

        // Set the data to EditText fields
        if (currentName != null) editTextName.setText(currentName);
        if (currentBio != null) editTextBio.setText(currentBio);
        if (currentWebsite != null) editTextWebsite.setText(currentWebsite);
        if (currentBirthDate != null) editTextBirthDate.setText(currentBirthDate);

        profileImageView = findViewById(R.id.profileImageView);
        coverImageView = findViewById(R.id.coverImageView);

        // Image picker for profile image
        profileImageView.setOnClickListener(v -> openImagePicker(1));

        // Image picker for cover image
        coverImageView.setOnClickListener(v -> openImagePicker(2));

        // Set up the DatePickerDialog for selecting birth date
        final Calendar calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);

        // ImageButton to show the DatePickerDialog
        ImageButton datePickerButton = findViewById(R.id.datePickerButton);
        datePickerButton.setOnClickListener(v -> {
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    EditProfileActivity.this,
                    (view, selectedYear, selectedMonth, selectedDay) -> {
                        selectedMonth = selectedMonth + 1; // Month is 0-based
                        String selectedDate = selectedDay + "/" + selectedMonth + "/" + selectedYear;
                        editTextBirthDate.setText(selectedDate);
                    },
                    year, month, day
            );
            datePickerDialog.show();
        });

        // Save button to send the updated data back to MainActivity
        Button saveButton = findViewById(R.id.saveButton);
        saveButton.setOnClickListener(v -> {
            // Retrieve updated data from EditText fields
            String updatedName = editTextName.getText().toString();
            String updatedBio = editTextBio.getText().toString();
            String updatedWebsite = editTextWebsite.getText().toString();
            String updatedBirthDate = editTextBirthDate.getText().toString();

            // Create an Intent to return updated data
            Intent resultIntent = new Intent();
            resultIntent.putExtra("updatedName", updatedName);
            resultIntent.putExtra("updatedBio", updatedBio);
            resultIntent.putExtra("updatedWebsite", updatedWebsite);
            resultIntent.putExtra("updatedBirthDate", updatedBirthDate);

            // Include image URIs if available
            if (profileImageUri != null) {
                resultIntent.putExtra("updatedProfileImageUri", profileImageUri.toString());
            }
            if (coverImageUri != null) {
                resultIntent.putExtra("updatedCoverImageUri", coverImageUri.toString());
            }

            // Set result and finish the activity
            setResult(RESULT_OK, resultIntent);
            finish();
        });

        // Find ImageView for backProfile button
        ImageView backProfile = findViewById(R.id.backProfile);

        // Set OnClickListener to close the activity and return to MainActivity
        backProfile.setOnClickListener(v -> {
            // Finish the EditProfileActivity and return to the previous activity (MainActivity)
            finish();
        });
    }

    private void openImagePicker(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && data != null) {
            Uri selectedImageUri = data.getData();
            if (requestCode == 1) {
                profileImageUri = selectedImageUri;
                profileImageView.setImageURI(profileImageUri);
            } else if (requestCode == 2) {
                coverImageUri = selectedImageUri;
                coverImageView.setImageURI(coverImageUri);
            }
        }
    }
}
