package com.example.praktikum8;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.praktikum8.Adapter.BookAdapter;
import com.example.praktikum8.Database.BookHelper;
import com.example.praktikum8.Database.DatabaseContract;
import com.example.praktikum8.Helper.MappingHelper;
import com.example.praktikum8.Model.Book;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvBooks;
    private BookAdapter adapter;
    private TextView noData;
    private EditText searchEditText; // Menggunakan EditText karena di XML Anda adalah EditText
    private FloatingActionButton fabAdd;
    private BookHelper bookHelper; // Deklarasi BookHelper

    private static final int REQUEST_ADD = 100;
    private static final int REQUEST_UPDATE = 200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Set judul ActionBar jika ada
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Notes Your Daily");
        }

        // Inisialisasi Views dari layout activity_main.xml
        rvBooks = findViewById(R.id.notes_recycler_view);
        noData = findViewById(R.id.noData);
        searchEditText = findViewById(R.id.search_edit_text);
        fabAdd = findViewById(R.id.fab_add);

        // Setup RecyclerView
        rvBooks.setLayoutManager(new LinearLayoutManager(this));
        adapter = new BookAdapter(this); // Mengirim 'this' (context/activity) ke adapter
        rvBooks.setAdapter(adapter);

        // Inisialisasi BookHelper dan buka koneksi database
        bookHelper = BookHelper.getInstance(getApplicationContext());
        bookHelper.open();

        // Setup Floating Action Button untuk menambah catatan baru
        fabAdd.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, AddBookActivity.class);
            startActivityForResult(intent, REQUEST_ADD); // Memulai AddBookActivity untuk menambah
        });

        // Setup TextWatcher untuk fungsionalitas pencarian
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Tidak perlu implementasi spesifik di sini
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Muat ulang buku dengan filter pencarian saat teks berubah
                loadBooks(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Tidak perlu implementasi spesifik di sini
            }
        });

        // Muat semua buku saat aplikasi pertama kali dimulai
        loadBooks("");
    }

    // Metode untuk memuat data buku dari database
    private void loadBooks(String query) {
        // Menggunakan AsyncTask pengganti untuk memuat data di background
        new LoadBooksAsync(this, books -> {
            if (books.size() > 0) {
                adapter.setBooks(books);
                noData.setVisibility(View.GONE); // Sembunyikan pesan "No Books Found"
            } else {
                adapter.setBooks(new ArrayList<>()); // Kosongkan adapter
                noData.setVisibility(View.VISIBLE); // Tampilkan pesan "No Books Found"
                showToast("Tidak ada catatan ditemukan");
            }
        }, query).execute();
    }

    // Metode untuk menangani hasil dari aktivitas lain (AddBookActivity)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_ADD) {
            if (resultCode == AddBookActivity.RESULT_ADD) {
                showToast("Catatan berhasil ditambahkan");
                loadBooks(searchEditText.getText().toString()); // Muat ulang daftar setelah penambahan
            }
        } else if (requestCode == REQUEST_UPDATE) { // Untuk edit atau hapus
            if (resultCode == AddBookActivity.RESULT_UPDATE) {
                showToast("Catatan berhasil diperbarui");
                loadBooks(searchEditText.getText().toString()); // Muat ulang daftar setelah pembaruan
            } else if (resultCode == AddBookActivity.RESULT_DELETE) {
                showToast("Catatan berhasil dihapus");
                loadBooks(searchEditText.getText().toString()); // Muat ulang daftar setelah penghapusan
            }
        }
    }

    // Metode helper untuk menampilkan Toast
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Tutup koneksi database saat Activity dihancurkan untuk mencegah kebocoran memori
        if (bookHelper != null) {
            bookHelper.close();
        }
    }

    // Kelas Asinkron untuk memuat data buku di background thread
    private static class LoadBooksAsync {
        private final WeakReference<Context> weakContext;
        private final WeakReference<LoadBooksCallback> weakCallback;
        private final String searchQuery; // Query pencarian

        private LoadBooksAsync(Context context, LoadBooksCallback callback, String searchQuery) {
            weakContext = new WeakReference<>(context);
            weakCallback = new WeakReference<>(callback);
            this.searchQuery = searchQuery;
        }

        void execute() {
            ExecutorService executor = Executors.newSingleThreadExecutor();
            Handler handler = new Handler(Looper.getMainLooper());

            executor.execute(() -> {
                Context context = weakContext.get();
                if (context != null) {
                    BookHelper bookHelper = BookHelper.getInstance(context);
                    bookHelper.open(); // Pastikan database dibuka

                    Cursor booksCursor;
                    if (searchQuery != null && !searchQuery.isEmpty()) {
                        // Jika ada query pencarian, filter berdasarkan judul atau deskripsi
                        booksCursor = bookHelper.database.query( // Menggunakan database yang sudah dibuka
                                DatabaseContract.TABLE_NAME,
                                null, // Semua kolom
                                DatabaseContract.BookColumns.JUDUL + " LIKE ? OR " + DatabaseContract.BookColumns.DESKRIPSI + " LIKE ?",
                                new String[]{"%" + searchQuery + "%", "%" + searchQuery + "%"},
                                null,
                                null,
                                DatabaseContract.BookColumns._ID + " ASC"
                        );
                    } else {
                        // Jika tidak ada query, ambil semua data
                        booksCursor = bookHelper.queryAll();
                    }

                    ArrayList<Book> books = MappingHelper.mapCursorToArrayList(booksCursor);
                    booksCursor.close(); // Penting untuk menutup cursor

                    // Kembali ke Main Thread untuk memperbarui UI
                    handler.post(() -> {
                        LoadBooksCallback callback = weakCallback.get();
                        if (callback != null) {
                            callback.postExecute(books);
                        }
                    });
                }
            });
        }
    }

    // Interface Callback untuk LoadBooksAsync
    interface LoadBooksCallback {
        void postExecute(ArrayList<Book> books);
    }
}