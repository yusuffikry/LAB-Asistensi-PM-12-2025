package com.example.praktikum8.Helper;

import android.database.Cursor;

import com.example.praktikum8.Database.DatabaseContract;
import com.example.praktikum8.Model.Book;

import java.util.ArrayList;

public class MappingHelper {

    public static ArrayList<Book> mapCursorToArrayList(Cursor cursor) {
        ArrayList<Book> books = new ArrayList<>();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseContract.BookColumns._ID));
            String judul = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.BookColumns.JUDUL));
            String deskripsi = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.BookColumns.DESKRIPSI));
            String createdAt = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.BookColumns.CREATED_AT));
            String updatedAt = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.BookColumns.UPDATED_AT));

            books.add(new Book(id, judul, deskripsi, createdAt, updatedAt));
        }
        return books;
    }
}