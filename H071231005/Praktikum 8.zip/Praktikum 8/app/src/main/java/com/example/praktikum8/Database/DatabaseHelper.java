package com.example.praktikum8.Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "books.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Gunakan konstanta dari DatabaseContract untuk konsistensi
        String SQL_CREATE_TABLE_BOOKS = String.format(
                "CREATE TABLE %s (" +
                        "%s INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "%s TEXT NOT NULL," +
                        "%s TEXT NOT NULL," +
                        "%s TEXT," + // Kolom created_at
                        "%s TEXT)",  // Kolom updated_at
                DatabaseContract.TABLE_NAME, // Nama tabel
                DatabaseContract.BookColumns._ID, // ID dari BaseColumns
                DatabaseContract.BookColumns.JUDUL,
                DatabaseContract.BookColumns.DESKRIPSI,
                DatabaseContract.BookColumns.CREATED_AT,
                DatabaseContract.BookColumns.UPDATED_AT
        );
        db.execSQL(SQL_CREATE_TABLE_BOOKS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        // Jika ada perubahan versi database, misalnya penambahan kolom
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DatabaseContract.TABLE_NAME);
        onCreate(sqLiteDatabase);
    }
}