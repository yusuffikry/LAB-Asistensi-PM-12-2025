package com.example.praktikum8;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.praktikum8.Database.BookHelper;
import com.example.praktikum8.Database.DatabaseContract;
import com.example.praktikum8.Model.Book;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddBookActivity extends AppCompatActivity {

    public static final String EXTRA_BOOK = "extra_book";
    public static final int RESULT_ADD = 101;
    public static final int RESULT_UPDATE = 201;
    public static final int RESULT_DELETE = 301;
    public static final int REQUEST_UPDATE = 200;

    private BookHelper bookHelper;
    private Book book;
    private TextInputEditText editTitle, editDescription;
    private Button btnSubmit;
    private ImageView btnBack; // Tambahkan tombol kembali

    private boolean isEdit = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        editTitle = findViewById(R.id.edit_title);
        editDescription = findViewById(R.id.edit_description);
        btnSubmit = findViewById(R.id.btn_submit);
        btnBack = findViewById(R.id.btn_back);

        bookHelper = BookHelper.getInstance(getApplicationContext());
        bookHelper.open();

        book = getIntent().getParcelableExtra(EXTRA_BOOK);

        if (book != null) {
            isEdit = true;
        } else {
            book = new Book();
        }

        String actionBarTitle;
        String buttonTitle;

        if (isEdit) {
            actionBarTitle = "Edit Catatan";
            buttonTitle = "UPDATE CATATAN";
            if (book != null) {
                editTitle.setText(book.getJudul());
                editDescription.setText(book.getDeskripsi());
            }
        } else {
            actionBarTitle = "Tambah Catatan";
            buttonTitle = "SIMPAN CATATAN";
        }

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(actionBarTitle);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        btnSubmit.setText(buttonTitle);
        btnSubmit.setOnClickListener(view -> saveBook());

        // Tambahkan listener untuk tombol kembali
        btnBack.setOnClickListener(v -> finish());
    }

    private void saveBook() {
        String title = editTitle.getText().toString().trim();
        String description = editDescription.getText().toString().trim();

        if (title.isEmpty()) {
            editTitle.setError("Judul tidak boleh kosong");
            return;
        }

        if (description.isEmpty()) {
            editDescription.setError("Deskripsi tidak boleh kosong");
            return;
        }

        book.setJudul(title);
        book.setDeskripsi(description);

        Intent intent = new Intent();
        intent.putExtra(EXTRA_BOOK, book);

        ContentValues values = new ContentValues();
        values.put(DatabaseContract.BookColumns.JUDUL, title);
        values.put(DatabaseContract.BookColumns.DESKRIPSI, description);

        // Dapatkan tanggal dan waktu saat ini
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss", Locale.getDefault());
        String currentDateTime = sdf.format(new Date());

        if (isEdit) {
            values.put(DatabaseContract.BookColumns.UPDATED_AT, currentDateTime); // Update updated_at
            long result = bookHelper.update(String.valueOf(book.getId()), values);
            if (result > 0) {
                setResult(RESULT_UPDATE, intent);
                finish();
            } else {
                Toast.makeText(this, "Gagal memperbarui data", Toast.LENGTH_SHORT).show();
            }
        } else {
            values.put(DatabaseContract.BookColumns.CREATED_AT, currentDateTime); // Set created_at
            values.put(DatabaseContract.BookColumns.UPDATED_AT, currentDateTime); // Set updated_at juga
            long result = bookHelper.insert(values);
            if (result > 0) {
                book.setId((int) result);
                setResult(RESULT_ADD, intent);
                finish();
            } else {
                Toast.makeText(this, "Gagal menambahkan data", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Untuk tombol kembali di ActionBar
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (bookHelper != null) {
            bookHelper.close();
        }
    }
}