package com.example.praktikum8.Database;

import android.provider.BaseColumns;

public class DatabaseContract {

    public static String TABLE_NAME = "books"; // Sesuaikan dengan nama tabel di DatabaseHelper

    public static final class BookColumns implements BaseColumns {
        public static String JUDUL = "judul";
        public static String DESKRIPSI = "deskripsi";
        public static String CREATED_AT = "created_at";
        public static String UPDATED_AT = "updated_at";
    }
}