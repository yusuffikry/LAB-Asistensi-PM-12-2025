package com.example.praktikum8.Adapter;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.praktikum8.AddBookActivity;
import com.example.praktikum8.Model.Book;
import com.example.praktikum8.R;

import java.util.ArrayList;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.BookViewHolder> {

    private final ArrayList<Book> books = new ArrayList<>();
    private final Activity activity;

    public BookAdapter(Activity activity) {
        this.activity = activity;
    }

    public void setBooks(ArrayList<Book> books) {
        this.books.clear();
        if (books.size() > 0) {
            this.books.addAll(books);
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public BookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_book, parent, false); // Menggunakan activity_book.xml sebagai item
        return new BookViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookViewHolder holder, int position) {
        holder.bind(books.get(position));
    }

    @Override
    public int getItemCount() {
        return books.size();
    }

    public class BookViewHolder extends RecyclerView.ViewHolder {

        final TextView tvJudul, tvDeskripsi, tvDate;
//        final CardView cardView; // Jika ada CardView di layout item Anda

        BookViewHolder(@NonNull View itemView) {
            super(itemView);
            tvJudul = itemView.findViewById(R.id.book_title);
            tvDeskripsi = itemView.findViewById(R.id.book_description);
            tvDate = itemView.findViewById(R.id.book_date);
//            cardView = itemView.findViewById(R.id.book_card_view); // Pastikan ID ini ada di activity_book.xml
        }

        void bind(Book book) {
            tvJudul.setText(book.getJudul());
            tvDeskripsi.setText(book.getDeskripsi());
            tvDate.setText(String.format("Created At %s", book.getCreatedAt())); // Asumsikan format tanggal

            itemView.setOnClickListener(v -> {
                Intent intent = new Intent(activity, AddBookActivity.class);
                intent.putExtra(AddBookActivity.EXTRA_BOOK, book);
                activity.startActivityForResult(intent, AddBookActivity.REQUEST_UPDATE);
            });
        }
    }
}