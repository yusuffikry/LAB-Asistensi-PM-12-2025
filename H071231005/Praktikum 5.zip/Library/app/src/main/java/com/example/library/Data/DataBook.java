package com.example.library.Data;

import com.example.library.Models.Book;
import com.example.library.R;

import java.util.ArrayList;

public class DataBook {
    public static ArrayList<Book> books = generateDummyBooks();

    private static ArrayList<Book> generateDummyBooks() {
        ArrayList<Book> books = new ArrayList<>();
        books.add(new Book(R.drawable.image1,
                "Minecraft",
                "Mojang Studios",
                2021,
                "Petualangan seru di dunia blok yang penuh misteri dan tantangan.",
                "Fantasy",
                "Seorang pemain terjebak di dunia Minecraft dan harus bertahan hidup sambil mengungkap rahasia besar yang tersembunyi.",
                250,
                false,
                4.8
        ));


        books.add(new Book(R.drawable.bumi,
                "Bumi",
                "Tere Liye",
                2014,
                "Petualangan remaja dengan kekuatan luar biasa.",
                "Fantasy",
                "Raib, Seli, dan Ali menjelajahi dunia paralel penuh misteri dan teknologi.",
                440,
                false,
                4.7
        ));

        books.add(new Book(R.drawable.bulan,
                "Bulan",
                "Tere Liye",
                2015,
                "Petualangan seru di dunia paralel yang penuh tantangan.",
                "Fantasy",
                "Kelanjutan kisah Raib, Seli, dan Ali yang menghadapi tantangan baru di dunia paralel Bulan.",
                432,
                false,
                4.8
        ));

        books.add(new Book(R.drawable.sagaras,
                "Sagaras",
                "Tere Liye",
                2021,
                "Petualangan seru di dunia paralel Sagaras.",
                "Fantasy",
                "Raib, Seli, dan Ali melanjutkan petualangan mereka di dunia paralel Sagaras, menghadapi tantangan baru yang penuh misteri.",
                400,
                false,
                4.9
        ));

        books.add(new Book(R.drawable.bibi_gili,
                "Bibi Gili",
                "Tere Liye",
                2020,
                "Kisah penuh makna tentang kehidupan dan keluarga.",
                "Drama",
                "Bibi Gili membawa pembaca pada perjalanan emosional yang menyentuh hati, penuh pelajaran hidup.",
                350,
                false,
                4.6
        ));

        books.add(new Book(R.drawable.lumpu,
                "Lumpu",
                "Tere Liye",
                2018,
                "Pertarungan epik melawan Lumpu di dunia paralel.",
                "Fantasy",
                "Raib, Seli, dan Ali menghadapi musuh kuat bernama Lumpu, yang mengancam keseimbangan dunia paralel.",
                420,
                false,
                4.8
        ));

        books.add(new Book(R.drawable.si_putih,
                "Si Putih",
                "Tere Liye",
                2019,
                "Kisah tentang Si Putih, makhluk misterius di dunia paralel.",
                "Fantasy",
                "Raib, Seli, dan Ali menemukan rahasia besar tentang Si Putih, yang menjadi kunci dalam petualangan mereka.",
                390,
                false,
                4.7
        ));

        books.add(new Book(R.drawable.nebula,
                "Nebula",
                "Tere Liye",
                2016,
                "Petualangan menegangkan di dunia paralel Nebula.",
                "Fantasy",
                "Raib, Seli, dan Ali menjelajahi dunia Nebula, menghadapi tantangan yang menguji keberanian mereka.",
                410,
                false,
                4.8
        ));

        books.add(new Book(R.drawable.selena,
                "Selena",
                "Tere Liye",
                2017,
                "Kisah tentang Selena, karakter penting di dunia paralel.",
                "Fantasy",
                "Selena mengungkapkan masa lalunya yang penuh misteri, memberikan petunjuk penting bagi Raib, Seli, dan Ali.",
                400,
                false,
                4.9
        ));

        books.add(new Book(R.drawable.komet_minor,
                "Komet Minor",
                "Tere Liye",
                2018,
                "Petualangan luar biasa di dunia paralel Komet Minor.",
                "Fantasy",
                "Raib, Seli, dan Ali menghadapi tantangan besar di dunia Komet Minor, yang penuh dengan kejutan dan bahaya.",
                430,
                false,
                4.8
        ));

        books.add(new Book(R.drawable.komet,
                "Komet",
                "Tere Liye",
                2018,
                "Petualangan luar biasa di dunia paralel Komet.",
                "Fantasy",
                "Raib, Seli, dan Ali menghadapi tantangan besar di dunia Komet, yang penuh dengan kejutan dan bahaya.",
                430,
                false,
                4.8
        ));

        books.add(new Book(R.drawable.ceros_dan_batazor,
                "Ceroz dan Batozar",
                "Tere Liye",
                2019,
                "Kisah tentang Ceroz dan Batozar di dunia paralel.",
                "Fantasy",
                "Raib, Seli, dan Ali menemukan rahasia besar tentang Ceroz dan Batozar, yang menjadi kunci dalam petualangan mereka.",
                390,
                false,
                4.7
        ));

        books.add(new Book(R.drawable.bintang,
                "Bintang",
                "Tere Liye",
                2017,
                "Petualangan menegangkan di dunia paralel Bintang.",
                "Fantasy",
                "Raib, Seli, dan Ali menjelajahi dunia Bintang, menghadapi tantangan yang menguji keberanian mereka.",
                410,
                false,
                4.8
        ));

        books.add(new Book(R.drawable.matahari,
                "Matahari",
                "Tere Liye",
                2016,
                "Petualangan seru di dunia paralel Matahari.",
                "Fantasy",
                "Raib, Seli, dan Ali melanjutkan petualangan mereka di dunia paralel Matahari, menghadapi tantangan baru yang penuh misteri.",
                400,
                false,
                4.9
        ));


        return books;
    }
}
