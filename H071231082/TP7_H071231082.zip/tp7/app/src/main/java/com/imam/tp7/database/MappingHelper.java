package com.imam.tp7.database;

import android.database.Cursor;

import java.util.ArrayList;

public class MappingHelper {
    public static ArrayList<Note> mapCursorToArrayList(Cursor noteCursor) {
        ArrayList<Note> notes = new ArrayList<>();
        while (noteCursor.moveToNext()) {
            int id = noteCursor.getInt(noteCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns._ID));
            String title = noteCursor.getString(noteCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.TITLE));
            String description = noteCursor.getString(noteCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.DESCRIPTION));
            String info = noteCursor.getString(noteCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.INFO));
            notes.add(new Note(id, title, description, info));
        }
        return notes;
    }
}
