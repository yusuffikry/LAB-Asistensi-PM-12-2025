package com.imam.tp7;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;
import com.imam.tp7.database.DatabaseContract;
import com.imam.tp7.database.Note;
import com.imam.tp7.database.NoteHelper;
import com.imam.tp7.databinding.ActivityFormBinding;
import android.app.AlertDialog;
import android.content.DialogInterface;

public class FormActivity extends AppCompatActivity {

    private ActivityFormBinding binding;
    public static final String EXTRA_NOTE = "extra_note";
    public static final int RESULT_ADD = 101;
    public static final int RESULT_UPDATE = 201;
    public static final int RESULT_DELETE = 301;
    public static final int REQUEST_UPDATE = 200;

    private Note note;
    private boolean isEdit = false;
    private NoteHelper noteHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityFormBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        noteHelper = NoteHelper.getInstance(getApplicationContext());
        noteHelper.open();

        note = getIntent().getParcelableExtra(EXTRA_NOTE);
        if (note != null) {
            isEdit = true;
        } else {
            note = new Note();
        }

        String actionBarTitle;
        String buttonTitle;
        if (isEdit) {
            actionBarTitle = "Edit Note";
            buttonTitle = "Update";
            if (note != null) {
                binding.titleInput.setText(note.getTitle());
                binding.descInput.setText(note.getDescription());
            }
            binding.btnDelete.setVisibility(View.VISIBLE);
            binding.navTitle.setText("Edit Note");
        } else {
            actionBarTitle = "Add Note";
            buttonTitle = "Save";
            binding.navTitle.setText("Add Note");
        }

        binding.btnSave.setText(buttonTitle);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(actionBarTitle);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        binding.btnSave.setOnClickListener(view -> saveNote());
        binding.btnDelete.setOnClickListener(view -> showDeleteConfirmationDialog());
        binding.btnBack.setOnClickListener(view -> {
            if (hasChanges()) {
                showBackConfirmationDialog();
            } else {
                finish();
            }
        });
    }

    private void saveNote() {
        String title = binding.titleInput.getText().toString().trim();
        String description = binding.descInput.getText().toString().trim();

        if (title.isEmpty()) {
            binding.titleInput.setError("Title is required");
            return;
        }
        if (description.isEmpty()) {
            binding.descInput.setError("Description is required");
            return;
        }

        String currentTime = getCurrentTime();

        note.setTitle(title);
        note.setDescription(description);
        note.setInfo(currentTime);

        Intent intent = new Intent();
        intent.putExtra(EXTRA_NOTE, note);

        ContentValues values = new ContentValues();
        values.put(DatabaseContract.NoteColumns.TITLE, title);
        values.put(DatabaseContract.NoteColumns.DESCRIPTION, description);
        values.put(DatabaseContract.NoteColumns.INFO, currentTime);

        if (isEdit) {
            long result = noteHelper.update(String.valueOf(note.getId()), values);
            if (result > 0) {
                setResult(RESULT_UPDATE, intent);
                finish();
            } else {
                Toast.makeText(this, "Failed to update note", Toast.LENGTH_SHORT).show();
            }
        } else {
            long result = noteHelper.insert(values);
            if (result > 0) {
                note.setId((int)result);
                setResult(RESULT_ADD, intent);
                finish();
            } else {
                Toast.makeText(this, "Failed to add note", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private String getCurrentTime() {
        long currentTimeMillis = System.currentTimeMillis();
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd MMM yyyy 'at' HH:mm", java.util.Locale.getDefault());
        if (isEdit) {
            return "Updated " + sdf.format(new java.util.Date(currentTimeMillis));
        } else {
            return "Created " + sdf.format(new java.util.Date(currentTimeMillis));
        }
    }

    private void deleteNote() {
        if (note != null && note.getId() > 0) {
            long result = noteHelper.deleteById(String.valueOf(note.getId()));
            if (result > 0) {
                setResult(RESULT_DELETE, null);
                finish();
            } else {
                Toast.makeText(this, "Failed to delete note", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "No note to delete", Toast.LENGTH_SHORT).show();
        }
    }

    private void showBackConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Discard Changes?")
               .setMessage("You have unsaved changes. Are you sure you want to discard them?")
               .setPositiveButton("Discard", (dialog, which) -> finish())
               .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
               .setCancelable(false)
               .show();
    }

    private void showDeleteConfirmationDialog() {
        new AlertDialog.Builder(this)
            .setTitle("Delete Note")
            .setMessage("Are you sure you want to delete this note?")
            .setPositiveButton("Delete", (dialog, which) -> deleteNote())
            .setNegativeButton("Cancel", null)
            .show();
    }

    private boolean hasChanges() {
        if (!isEdit) {
            // For new notes, check if any field has content
            return !binding.titleInput.getText().toString().trim().isEmpty() ||
                   !binding.descInput.getText().toString().trim().isEmpty();
        } else {
            // For existing notes, check if content has changed
            return !binding.titleInput.getText().toString().trim().equals(note.getTitle()) ||
                   !binding.descInput.getText().toString().trim().equals(note.getDescription());
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (noteHelper != null) {
            noteHelper.close();
        }
    }

    @Override
    public void onBackPressed() {
        if (hasChanges()) {
            showBackConfirmationDialog();
        } else {
            super.onBackPressed();
        }
    }
}