package com.imam.tp4;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

public class MainActivity extends AppCompatActivity {
    private ImageView homeBtn, addBtn, favouriteBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        homeBtn = findViewById(R.id.homeBtn);
        addBtn = findViewById(R.id.uploadBtn);
        favouriteBtn = findViewById(R.id.favBtn);
        homeBtn.setOnClickListener(v -> ReplaceFragment(new HomeFragment()));
        addBtn.setOnClickListener(v -> ReplaceFragment(new AddFragment()));
        favouriteBtn.setOnClickListener(v -> ReplaceFragment(new FavouriteFragment()));
        ReplaceFragment(new HomeFragment());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void ReplaceFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit();
    }

    public void notifyBooksAdapter() {
        HomeFragment homeFragment = (HomeFragment) getSupportFragmentManager().findFragmentByTag("homeFragment");
        if (homeFragment != null) {
            homeFragment.refreshBooks();
        }
    }
}