package com.imam.tp4;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class DetailActivity extends AppCompatActivity {

    private ImageView cover, backBtn, favBtn;
    private TextView title, author, year, sinopsis;
    private Books book;
    private int position = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        cover = findViewById(R.id.cover);
        title = findViewById(R.id.title);
        author = findViewById(R.id.author);
        year = findViewById(R.id.year);
        sinopsis = findViewById(R.id.sinopsis);
        backBtn = findViewById(R.id.backBtn);
        favBtn = findViewById(R.id.favBtn);

        book = getIntent().getParcelableExtra("book");
        position = getIntent().getIntExtra("position", -1);

        if (book != null && position != -1) {
            title.setText(book.getTitle());
            author.setText(book.getAuthor());
            year.setText(String.valueOf(book.getYear()));
            sinopsis.setText(book.getDescription());

            Uri uriCover = Uri.parse(book.getImageUrl());
            Glide.with(this).load(uriCover).into(cover);

            setupFavoriteButton();
        }

        backBtn.setOnClickListener(v -> finish());
    }

    private void setupFavoriteButton() {
        updateFavButtonIcon(book.isFavourite());

        favBtn.setOnClickListener(v -> {
            boolean newFavStatus = !book.isFavourite();
            book.setFavourite(newFavStatus);
            DataDummy.books.get(position).setFavourite(newFavStatus);
            updateFavButtonIcon(newFavStatus);
        });
    }

    private void updateFavButtonIcon(boolean isFavourite) {
        int iconRes = isFavourite ? R.drawable.favicon : R.drawable.bookmark;
        favBtn.setImageResource(iconRes);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        // Notify fragments of changes when going back
        Intent intent = new Intent("BOOK_FAVORITE_CHANGED");
        sendBroadcast(intent);
    }
}