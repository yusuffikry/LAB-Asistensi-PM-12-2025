package com.imam.tp4;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.SearchEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.SearchView;

public class HomeFragment extends Fragment {
    public RecyclerView recyclerView;
    public BookAdapter bookAdapter;
    public SearchView searchView;
    private ProgressBar progressBar;
    private Runnable filterRunnable;
    private Handler filterHandler = new Handler();
    private Runnable searchRunnable;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        recyclerView = view.findViewById(R.id.rvHomeBook);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));

        bookAdapter = new BookAdapter(DataDummy.books, (book, position) -> {
            Intent intent = new Intent(getActivity(), DetailActivity.class);
            intent.putExtra("book", book);
            intent.putExtra("position", position);
            startActivity(intent);
        });

        // Setup SearchView
        SearchView searchView = view.findViewById(R.id.search_bar);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                performSearch(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                progressBar = view.findViewById(R.id.progressBar);
                // Cancel previous search if still running
                filterHandler.removeCallbacks(filterRunnable);

                progressBar.setVisibility(View.VISIBLE);

                filterRunnable = () -> {
                    bookAdapter.filter(newText, () -> {
                        progressBar.setVisibility(View.GONE);
                    });
                };

                searchRunnable = () -> performSearch(newText);
                filterHandler.postDelayed(searchRunnable, 300);
                return true;
            }
        });

        recyclerView.setAdapter(bookAdapter);
        return view;
    }

    private void performSearch(String query) {
        bookAdapter.filter(query, new BookAdapter.FilterListener() {
            @Override
            public void onFilterComplete() {
                progressBar.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        // Clear search when returning to fragment
        if (searchView != null) {
            searchView.setQuery("", false);
            searchView.clearFocus();
        }
    }
    public void refreshBooks() {
        if (bookAdapter != null) {
            bookAdapter.notifyDataSetChanged();
        }
    }
}