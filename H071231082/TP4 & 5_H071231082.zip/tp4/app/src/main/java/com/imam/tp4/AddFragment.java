package com.imam.tp4;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

public class AddFragment extends Fragment {

    private Uri imageUri;
    private TextInputEditText title, author, description, year;
    private static final int GALLERY_REQUEST_CODE = 1;
    private Button submitBtn;
    private ImageView cover;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_add, container, false);

        title = view.findViewById(R.id.title);
        author = view.findViewById(R.id.author);
        description = view.findViewById(R.id.description);
        year = view.findViewById(R.id.year);
        cover = view.findViewById(R.id.cover);
        submitBtn = view.findViewById(R.id.submitBtn);

        cover.setOnClickListener(v -> {
            // Open gallery to select an image
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");
            startActivityForResult(intent, GALLERY_REQUEST_CODE);
        });

        submitBtn.setOnClickListener(v -> {
            String titleText = title.getText().toString();
            String authorText = author.getText().toString();
            String descriptionText = description.getText().toString();
            String yearText = year.getText().toString();

            if (imageUri == null) {
                Toast.makeText(getActivity(), "Please select an image", Toast.LENGTH_SHORT).show();
                return;
            }


            if (imageUri != null && !titleText.isEmpty() && !authorText.isEmpty() && !descriptionText.isEmpty() && !yearText.isEmpty()) {
                int year = 0;
                try {
                    year = Integer.parseInt(yearText);
                } catch (NumberFormatException e) {
                    Toast.makeText(getActivity(), "Invalid year, please input year in digit", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                    return;
                }

                Books newBook = new Books(titleText, authorText, descriptionText, imageUri.toString(), year);
                DataDummy.books.add(newBook);


                if (getActivity() instanceof MainActivity) {
                    ((MainActivity) getActivity()).notifyBooksAdapter();
                }

                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment())
                        .addToBackStack(null).commit();
            }
        });
        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GALLERY_REQUEST_CODE && resultCode == getActivity().RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            cover.setImageURI(imageUri);
        }
    }
}