package com.imam.tp4;

import java.util.ArrayList;

public class DataDummy {
    public static ArrayList<Books> books = getBooks();

    public static ArrayList<Books> getBooks() {
        ArrayList<Books> books = new ArrayList<>();
        books.add(new Books("I Want to Keep Smashing Myself Until I Am Whole", "Joshua Cohen", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas iaculis lorem sed nulla consectetur vestibulum egestas id lorem. Morbi mollis condimentum varius. Curabitur aliquet justo quis leo dapibus accumsan. Vivamus quam orci, suscipit ac pharetra vel, volutpat id magna. Sed feugiat at mauris faucibus iaculis. Donec bibendum ante a ex imperdiet ullamcorper sit amet in diam. Maecenas ut urna mollis, finibus ante vitae, mollis enim. In varius feugiat neque, sit amet tincidunt quam lacinia id. Vivamus ullamcorper diam sit amet congue pulvinar. Etiam blandit felis sed sagittis faucibus. Mauris sed nunc tincidunt, tincidunt lacus at, faucibus orci. In auctor est id leo porttitor finibus. Sed magna sapien, rhoncus sit amet ante eu, cursus luctus magna. Duis at lorem a velit imperdiet rutrum ac vel lacus. Suspendisse maximus lorem ac nisi malesuada hendrerit. Nunc sed risus facilisis, bibendum ipsum vel, porta orci.", "android.resource://com.imam.tp4/drawable/cover1", 2018));

        books.add(new Books("No Land In Sight", "Charles Simic", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas iaculis lorem sed nulla consectetur vestibulum egestas id lorem. Morbi mollis condimentum varius. Curabitur aliquet justo quis leo dapibus accumsan. Vivamus quam orci, suscipit ac pharetra vel, volutpat id magna. Sed feugiat at mauris faucibus iaculis. ", "android.resource://com.imam.tp4/drawable/cover2", 2015));

        books.add(new Books("Darling Girls", "Sally Hepsworth", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas iaculis lorem sed nulla consectetur vestibulum egestas id lorem. Morbi mollis condimentum varius. Curabitur aliquet justo quis leo dapibus accumsan. Vivamus quam orci, suscipit ac pharetra vel, volutpat id magna. Sed feugiat at mauris faucibus iaculis. ", "android.resource://com.imam.tp4/drawable/cover3", 2016));

        books.add(new Books("Charlie Soto Is Back", "Taylor Jenkins Rec", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas iaculis lorem sed nulla consectetur vestibulum egestas id lorem. Morbi mollis condimentum varius. Curabitur aliquet justo quis leo dapibus accumsan. Vivamus quam orci, suscipit ac pharetra vel, volutpat id magna. Sed feugiat at mauris faucibus iaculis. ", "android.resource://com.imam.tp4/drawable/cover4", 2017));

        books.add(new Books("Pure Colour", "Sheila Heti", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas iaculis lorem sed nulla consectetur vestibulum egestas id lorem. Morbi mollis condimentum varius. Curabitur aliquet justo quis leo dapibus accumsan. Vivamus quam orci, suscipit ac pharetra vel, volutpat id magna. Sed feugiat at mauris faucibus iaculis. ", "android.resource://com.imam.tp4/drawable/cover5", 2018));

        books.add(new Books("Love", "Maayan Eitan", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas iaculis lorem sed nulla consectetur vestibulum egestas id lorem. Morbi mollis condimentum varius. Curabitur aliquet justo quis leo dapibus accumsan. Vivamus quam orci, suscipit ac pharetra vel, volutpat id magna. Sed feugiat at mauris faucibus iaculis. ", "android.resource://com.imam.tp4/drawable/cover6", 2019));

        books.add(new Books("The Saint Of Bright Doors", "Vajra Chandrasekera", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas iaculis lorem sed nulla consectetur vestibulum egestas id lorem. Morbi mollis condimentum varius. Curabitur aliquet justo quis leo dapibus accumsan. Vivamus quam orci, suscipit ac pharetra vel, volutpat id magna. Sed feugiat at mauris faucibus iaculis. ", "android.resource://com.imam.tp4/drawable/cover7", 2020));

        books.add(new Books("Bliss Montage", "Ling Ma", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas iaculis lorem sed nulla consectetur vestibulum egestas id lorem. Morbi mollis condimentum varius. Curabitur aliquet justo quis leo dapibus accumsan. Vivamus quam orci, suscipit ac pharetra vel, volutpat id magna. Sed feugiat at mauris faucibus iaculis. ", "android.resource://com.imam.tp4/drawable/cover8", 2021));

        books.add(new Books("Valleyesque", "Fernando A. Flores", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas iaculis lorem sed nulla consectetur vestibulum egestas id lorem. Morbi mollis condimentum varius. Curabitur aliquet justo quis leo dapibus accumsan. Vivamus quam orci, suscipit ac pharetra vel, volutpat id magna. Sed feugiat at mauris faucibus iaculis. ", "android.resource://com.imam.tp4/drawable/cover9", 2022));

        books.add(new Books("Planes", "Peter C. Baker", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas iaculis lorem sed nulla consectetur vestibulum egestas id lorem. Morbi mollis condimentum varius. Curabitur aliquet justo quis leo dapibus accumsan. Vivamus quam orci, suscipit ac pharetra vel, volutpat id magna. Sed feugiat at mauris faucibus iaculis. ", "android.resource://com.imam.tp4/drawable/cover10", 2023));


        return books;
    }
}

