package com.imam.tp4;

import android.os.Parcel;
import android.os.Parcelable;

public class Books implements Parcelable{
    private String title;
    private String author;
    private String description;
    private String imageUrl;
    private int year;

    private boolean isFavourite;

    public Books(String title, String author, String description, String imageUrl, int year) {
        this.title = title;
        this.author = author;
        this.description = description;
        this.imageUrl = imageUrl;
        this.year = year;
        this.isFavourite = false;
    }

    protected Books(Parcel in) {
        title = in.readString();
        author = in.readString();
        description = in.readString();
        imageUrl = in.readString();
        year = in.readInt();
        isFavourite = in.readByte() != 0;
    }

    public static final Parcelable.Creator<Books> CREATOR = new Parcelable.Creator<Books>() {
        @Override
        public Books createFromParcel(Parcel in) {
            return new Books(in);
        }

        @Override
        public Books[] newArray(int size) {
            return new Books[size];
        }
    };

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(author);
        dest.writeString(description);
        dest.writeString(imageUrl);
        dest.writeInt(year);
        dest.writeByte((byte) (isFavourite ? 1 : 0));
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public boolean isFavourite() {
        return isFavourite;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setFavourite(boolean favourite) {
        isFavourite = favourite;
    }
}
