package com.imam.tp4;

import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.BookViewHolder> {

    private final List<Books> booksList;
    private List<Books> booksListFull;
    private final OnItemClickListener listener;
    private Handler handler = new Handler(Looper.getMainLooper());


    public interface OnItemClickListener {
        void onItemClick(Books book, int position);
    }

    public BookAdapter(List<Books> booksList, OnItemClickListener listener) {
        this.booksList = booksList;
        this.booksListFull = new ArrayList<>(booksList);
        this.listener = listener;
    }

    public interface FilterListener {
        void onFilterComplete();
    }

    public void filter(String text, FilterListener filterListener) {
        new Thread(() -> {
            List<Books> filteredList = new ArrayList<>();

            if (text.isEmpty()) {
                filteredList.addAll(booksListFull);
            } else {
                String[] searchTerms = text.toLowerCase().trim().split("\\s+");
                for (Books book : booksListFull) {
                    boolean matches = true;
                    String title = book.getTitle().toLowerCase();
                    String author = book.getAuthor().toLowerCase();

                    for (String term : searchTerms) {
                        if (!title.contains(term) && !author.contains(term)) {
                            matches = false;
                            break;
                        }
                    }
                    if (matches) filteredList.add(book);
                }
            }

            handler.post(() -> {
                booksList.clear();
                booksList.addAll(filteredList);
                notifyDataSetChanged();
                filterListener.onFilterComplete();
            });
        }).start();
    }

    @Override
    public BookViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.book_item, parent, false);
        return new BookViewHolder(view);
    }

    @Override
    public void onBindViewHolder(BookViewHolder holder, int position) {
        Books book = booksList.get(position);
        holder.bind(book, position, listener);
    }

    @Override
    public int getItemCount() {
        return booksList.size();
    }

    static class BookViewHolder extends RecyclerView.ViewHolder {
        ImageView bookImage;
        TextView bookTitle;
        TextView bookAuthor;  // Add this field

        public BookViewHolder(@NonNull View itemView) {
            super(itemView);
            bookImage = itemView.findViewById(R.id.img);
            bookTitle = itemView.findViewById(R.id.title);
            bookAuthor = itemView.findViewById(R.id.author);
        }

        public void bind(Books book, int position, OnItemClickListener listener) {
            bookTitle.setText(book.getTitle());
            bookAuthor.setText(book.getAuthor());

            Uri uriCover = Uri.parse(book.getImageUrl());
            Glide.with(itemView.getContext())
                    .load(uriCover)
                    .into(bookImage);

            itemView.setOnClickListener(v -> listener.onItemClick(book, position));
        }
    }
}