package com.example.tp3;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import de.hdodenhof.circleimageview.CircleImageView;

public class DummyProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dummy_profile);

        // Get data from intent
        String username = getIntent().getStringExtra("USERNAME");
        String profileImage = getIntent().getStringExtra("PROFILE_IMAGE");

        // Initialize views
        CircleImageView profileImageView = findViewById(R.id.profile_image);
        TextView usernameTextView = findViewById(R.id.username);
        ImageView btnBack = findViewById(R.id.btn_back);

        // Set profile data
        usernameTextView.setText(username);

        // Load profile image
        int pfpResId = getResources().getIdentifier(
                profileImage,
                "drawable",
                getPackageName()
        );
        Glide.with(this).load(pfpResId).into(profileImageView);

        // Setup back button
        btnBack.setOnClickListener(v -> finish());
    }
}