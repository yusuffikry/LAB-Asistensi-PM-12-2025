package com.example.tp3;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class FeedAdapter extends RecyclerView.Adapter<FeedAdapter.FeedViewHolder> {
    private Context context;
    private List<FeedItem> feedItems;

    public FeedAdapter(Context context, List<FeedItem> feedItems) {
        this.context = context;
        this.feedItems = feedItems;
    }

    @NonNull
    @Override
    public FeedViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.home_item, parent, false);
        return new FeedViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FeedViewHolder holder, int position) {
        FeedItem item = feedItems.get(position);

        // Hanya set data yang dibutuhkan
        holder.username.setText(item.getUsername());
        holder.caption.setText(item.getCaption());

        // Untuk gambar, gunakan resource lokal
        holder.content.setImageResource(
                context.getResources().getIdentifier(
                        item.getPostImage(),
                        "drawable",
                        context.getPackageName()
                )
        );

        holder.pfp.setImageResource(
                context.getResources().getIdentifier(
                        item.getProfilePic(),
                        "drawable",
                        context.getPackageName()
                )
        );

        // Set click listeners for profile navigation
        holder.pfp.setOnClickListener(v -> openDummyProfile(item));
        holder.username.setOnClickListener(v -> openDummyProfile(item));
    }

    @Override
    public int getItemCount() {
        return feedItems.size();
    }

    private void openDummyProfile(FeedItem item) {
        Intent intent = new Intent(context, DummyProfileActivity.class);
        intent.putExtra("USERNAME", item.getUsername());
        intent.putExtra("PROFILE_IMAGE", item.getProfilePic());
        context.startActivity(intent);
    }

    public void updateFeedItems(List<FeedItem> newFeedItems) {
        this.feedItems = newFeedItems;
        notifyDataSetChanged();
    }

    public static class FeedViewHolder extends RecyclerView.ViewHolder {
        ImageView pfp, content;
        TextView username, caption;

        public FeedViewHolder(@NonNull View itemView) {
            super(itemView);
            pfp = itemView.findViewById(R.id.pfp);
            username = itemView.findViewById(R.id.username);
            content = itemView.findViewById(R.id.content);
            caption = itemView.findViewById(R.id.caption);
        }
    }
}