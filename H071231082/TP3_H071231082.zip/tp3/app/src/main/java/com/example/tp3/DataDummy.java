package com.example.tp3;

import java.util.ArrayList;
import java.util.List;

public class DataDummy {
    private static List<ProfileFeedItem> postedItems = new ArrayList<>();
    private static List<ProfileFeedItem> dummyItems = new ArrayList<>();
    
    // Initialize with some default items
    static {
        // Initialize dummy items
        dummyItems.add(new ProfileFeedItem(
                "img1",
                "100 likes",
                "Caption pertama saya"
        ));
        dummyItems.add(new ProfileFeedItem(
                "img2",
                "85 likes",
                "Hari yang menyenangkan"
        ));
        dummyItems.add(new ProfileFeedItem(
                "img3",
                "120 likes",
                "Liburan akhir pekan"
        ));
    }

    public static void addNewPost(String imageUrl, String caption) {
        postedItems.add(0, new ProfileFeedItem(
                imageUrl,
                "0 likes",
                caption
        ));
    }

    public static List<FeedItem> generateDummyFeed() {
        List<FeedItem> feedItems = new ArrayList<>();

        feedItems.add(new FeedItem(
                "first_person",
                "img1",
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
                "img3"
        ));

        feedItems.add(new FeedItem(
                "second_person",
                "img2", // atau gambar lain jika ada
                "Mauris vel imperdiet eros, quis mollis mauris. Ut fringilla est vel urna luctus, vel accumsan mi tincidunt.",
                "img5"
        ));

        feedItems.add(new FeedItem(
                "third_person",
                "img3",
                "Suspendisse placerat placerat eros pellentesque tempor. Quisque ac auctor libero, feugiat sagittis nunc.",
                "img5"
        ));

        feedItems.add(new FeedItem(
                "fourth_person",
                "img4",
                " Aenean nunc urna, maximus eget bibendum sit amet, viverra sed ipsum.",
                "img2"
        ));

        feedItems.add(new FeedItem(
                "fifth_person",
                "img5",
                "Sed sit amet magna dignissim, tempor nisl non, semper dolor.",
                "img7"
        ));

        feedItems.add(new FeedItem(
                "sixth_person",
                "img6",
                "Cras mattis venenatis volutpat. Nam lectus massa, suscipit sit amet nibh eu, maximus congue urna.",
                "img1"
        ));

        feedItems.add(new FeedItem(
                "seventh_person",
                "img7",
                "Nam iaculis urna id lorem imperdiet, in facilisis tellus placerat. Integer et ipsum volutpat, finibus leo vitae, facilisis dolor",
                "img4"
        ));

        feedItems.add(new FeedItem(
                "eighth_person",
                "img8",
                "Vestibulum porttitor, urna vitae tincidunt tristique, velit turpis hendrerit nibh, vitae congue enim mauris quis enim.",
                "img6"
        ));

        feedItems.add(new FeedItem(
                "ninth_person",
                "img9",
                "Sed sit amet pellentesque metus, non tempor ipsum. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.",
                "img10"
        ));

        feedItems.add(new FeedItem(
                "tenth_person",
                "img10",
                "Vivamus non ullamcorper sem, non scelerisque diam.",
                "img9"
        ));

        return feedItems;
    }

    public static List<ProfileFeedItem> generateProfileFeed() {
        List<ProfileFeedItem> result = new ArrayList<>();
        // Add posted items first
        result.addAll(postedItems);
        // Add dummy items if there are no posted items
        if (result.isEmpty()) {
            result.addAll(dummyItems);
        }
        return result;
    }

    public static List<StoryItem> generateDummyStories() {
        List<StoryItem> stories = new ArrayList<>();

        stories.add(new StoryItem("1", "img3",false));
        stories.add(new StoryItem("2", "img4",false));
        stories.add(new StoryItem("3", "img2",false));
        stories.add(new StoryItem("4", "img6",false));
        stories.add(new StoryItem("5", "img7",false));
        stories.add(new StoryItem("6", "img8",false));

        return stories;
    }
}
