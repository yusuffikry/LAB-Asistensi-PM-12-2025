package com.example.tp3;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;
import de.hdodenhof.circleimageview.CircleImageView;

public class StoryAdapter extends RecyclerView.Adapter<StoryAdapter.StoryViewHolder> {
    private Context context;
    private List<StoryItem> stories;

    public StoryAdapter(Context context, List<StoryItem> stories) {
        this.context = context;
        this.stories = stories != null ? stories : new ArrayList<>();
    }

    @NonNull
    @Override
    public StoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.story_item, parent, false);
        return new StoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StoryViewHolder holder, int position) {
        StoryItem story = stories.get(position);

        // Load story image
        int resId = context.getResources().getIdentifier(
                story.getImageUrl(),
                "drawable",
                context.getPackageName()
        );

        // Set border color based on viewed status
        int borderColor = story.isViewed() ?
                R.color.story_viewed : R.color.story_unviewed;

        holder.storyImage.setBorderColor(context.getResources().getColor(borderColor));
        Glide.with(context).load(resId).into(holder.storyImage);
        holder.username.setText(story.getUsername());

        holder.itemView.setOnClickListener(v -> {
            // Launch HighlightActivity
            Intent intent = new Intent(context, HighlightActivity.class);
            intent.putExtra("STORY_TITLE", story.getUsername());
            intent.putExtra("STORY_IMAGE", resId);
            context.startActivity(intent);

            // Mark as viewed
            story.setViewed(true);
            notifyItemChanged(position);
        });
    }

    @Override
    public int getItemCount() {
        return stories.size();
    }

    public static class StoryViewHolder extends RecyclerView.ViewHolder {
        CircleImageView storyImage;
        TextView username;

        public StoryViewHolder(@NonNull View itemView) {
            super(itemView);
            storyImage = itemView.findViewById(R.id.story_image);
            username = itemView.findViewById(R.id.story_username);
        }
    }
}