package com.example.tp3;

public class FeedItem {
    private String username;
    private String postImage;
    private String caption;
    private String profilePic;

    public FeedItem(String username, String postImage, String caption, String profilePic) {
        this.username = username;
        this.postImage = postImage;
        this.caption = caption;
        this.profilePic = profilePic;
    }

    // Getter methods
    public String getUsername() { return username; }
    public String getPostImage() { return postImage; }
    public String getCaption() { return caption; }
    public String getProfilePic() { return profilePic; }
}