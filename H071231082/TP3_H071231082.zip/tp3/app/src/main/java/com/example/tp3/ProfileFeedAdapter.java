package com.example.tp3;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;

public class ProfileFeedAdapter extends RecyclerView.Adapter<ProfileFeedAdapter.ProfileFeedViewHolder> {
    private Context context;
    private List<ProfileFeedItem> profileFeedItems;

    public ProfileFeedAdapter(Context context, List<ProfileFeedItem> profileFeedItems) {
        this.context = context;
        this.profileFeedItems = profileFeedItems;
    }

    @NonNull
    @Override
    public ProfileFeedViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.feed_profile_item, parent, false);
        return new ProfileFeedViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProfileFeedViewHolder holder, int position) {
        ProfileFeedItem item = profileFeedItems.get(position);
        String imageUrl = item.getImageUrl();

        // Check if the imageUrl is a URI (starts with content:// or file://)
        if (imageUrl.startsWith("content://") || imageUrl.startsWith("file://")) {
            // Load image from URI using Glide
            Glide.with(context)
                .load(Uri.parse(imageUrl))
                .centerCrop()
                .into(holder.feedImage);
        } else {
            // Load image from drawable resource
            int resId = context.getResources().getIdentifier(
                    imageUrl,
                    "drawable",
                    context.getPackageName()
            );
            if (resId != 0) {
                holder.feedImage.setImageResource(resId);
            }
        }

        holder.itemView.setOnClickListener(v -> {
            Fragment fragment = FeedProfileFragment.newInstance(
                    item.getImageUrl(),
                    item.getCaption()
            );

            if (context instanceof FragmentActivity) {
                ((FragmentActivity) context).getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment_container, fragment)
                        .addToBackStack(null)
                        .commit();
            }
        });
    }

    @Override
    public int getItemCount() {
        return profileFeedItems.size();
    }

    public void updateProfileFeedItems(List<ProfileFeedItem> newProfileFeedItems) {
        this.profileFeedItems = newProfileFeedItems;
        notifyDataSetChanged();
    }

    public static class ProfileFeedViewHolder extends RecyclerView.ViewHolder {
        ImageView feedImage;

        public ProfileFeedViewHolder(@NonNull View itemView) {
            super(itemView);
            feedImage = itemView.findViewById(R.id.feed_image);
        }
    }
}