package com.example.tp3;

import static android.app.Activity.RESULT_OK;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.Manifest;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

public class PostFragment extends Fragment {
    private static final String TAG = "PostFragment";
    private ImageView imagePreview;
    private LinearLayout placeholderLayout;
    private EditText etCaption;
    private Uri selectedImageUri;

    // Modern way to handle activity results
    private final ActivityResultLauncher<Intent> galleryLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    handleSelectedImage(result.getData().getData());
                }
            });

    private final ActivityResultLauncher<String> permissionLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(),
            isGranted -> {
                if (isGranted) {
                    openGallery();
                } else {
                    Toast.makeText(requireContext(),
                            "Permission needed to access photos",
                            Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_post, container, false);

        initializeViews(view);
        setupClickListeners(view);

        return view;
    }

    private void initializeViews(View view) {
        imagePreview = view.findViewById(R.id.image_preview);
        placeholderLayout = view.findViewById(R.id.placeholder_layout);
        etCaption = view.findViewById(R.id.et_caption);
    }

    private void setupClickListeners(View view) {
        view.findViewById(R.id.btn_select_image).setOnClickListener(v -> checkPermissionsAndOpenGallery());

        view.findViewById(R.id.btn_share).setOnClickListener(v -> {
            if (selectedImageUri != null) {
                uploadPost();
            } else {
                showToast("Please select an image first");
            }
        });
    }

    private void checkPermissionsAndOpenGallery() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13+ uses READ_MEDIA_IMAGES
            if (ContextCompat.checkSelfPermission(requireContext(),
                    Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED) {
                openGallery();
            } else {
                permissionLauncher.launch(Manifest.permission.READ_MEDIA_IMAGES);
            }
        } else {
            // For older versions use READ_EXTERNAL_STORAGE
            if (ContextCompat.checkSelfPermission(requireContext(),
                    Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                openGallery();
            } else {
                permissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE);
            }
        }
    }

    private void openGallery() {
        try {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT,
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent.setType("image/*");
            galleryLauncher.launch(intent);
        } catch (Exception e) {
            Log.e(TAG, "Error opening gallery", e);
            showToast("Failed to open gallery");
        }
    }

    private void handleSelectedImage(Uri imageUri) {
        if (imageUri != null) {
            selectedImageUri = imageUri;
            try {
                // Using Glide for better image handling
                Glide.with(this)
                        .load(imageUri)
                        .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .skipMemoryCache(true)
                        .into(imagePreview);

                imagePreview.setVisibility(View.VISIBLE);
                placeholderLayout.setVisibility(View.GONE);
            } catch (Exception e) {
                Log.e(TAG, "Error loading image", e);
                showToast("Failed to load image");
            }
        }
    }

    private void uploadPost() {
        String caption = etCaption.getText().toString().trim();

        if (caption.isEmpty()) {
            showToast("Please enter a caption");
            return;
        }

        // Add the new post to DataDummy
        DataDummy.addNewPost(selectedImageUri.toString(), caption);

        showToast("Post Success");
        resetForm();

        // Navigate back to profile fragment
        if (getActivity() != null) {
            getActivity().getSupportFragmentManager().popBackStack();
        }
    }

    private void resetForm() {
        imagePreview.setVisibility(View.GONE);
        placeholderLayout.setVisibility(View.VISIBLE);
        etCaption.setText("");
        selectedImageUri = null;
    }

    private void showToast(String message) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
    }
}
