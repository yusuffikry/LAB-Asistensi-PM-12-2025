package com.example.tp3;

import java.io.Serializable;

public class ProfileFeedItem implements Serializable {
    private String imageUrl;
    private String likes;
    private String caption;

    public ProfileFeedItem(String imageUrl, String likes, String caption) {
        this.imageUrl = imageUrl;
        this.likes = likes;
        this.caption = caption;
    }

    // Getter methods
    public String getImageUrl() { return imageUrl; }
    public String getLikes() { return likes; }
    public String getCaption() { return caption; }
}