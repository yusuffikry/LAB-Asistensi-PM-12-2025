package com.example.tp3;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class ProfileFragment extends Fragment {
    private RecyclerView profileFeedRecyclerView;
    private ProfileFeedAdapter profileFeedAdapter;
    private List<ProfileFeedItem> profileFeedItems = new ArrayList<>();
    private RecyclerView storyRecyclerView;
    private StoryAdapter storyAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        profileFeedItems.addAll(DataDummy.generateProfileFeed());

        // Setup profile feed
        profileFeedRecyclerView = view.findViewById(R.id.rv_profile_feed);
        profileFeedRecyclerView.setLayoutManager(new GridLayoutManager(getContext(), 3));

        // Setup adapter
        profileFeedAdapter = new ProfileFeedAdapter(getContext(), profileFeedItems);
        profileFeedRecyclerView.setAdapter(profileFeedAdapter);

        // Setup story highlights
        storyRecyclerView = view.findViewById(R.id.story_highlight);
        storyRecyclerView.setLayoutManager(new LinearLayoutManager(
                getContext(),
                LinearLayoutManager.HORIZONTAL,
                false
        ));

        List<StoryItem> stories = DataDummy.generateDummyStories();
        storyAdapter = new StoryAdapter(requireActivity(), stories);
        storyRecyclerView.setAdapter(storyAdapter);

        return view;
    }

    public void addNewPost(ProfileFeedItem newPost) {
        if (profileFeedItems != null && profileFeedAdapter != null){
            profileFeedItems.add(0, newPost); // Tambahkan di awal list
            profileFeedAdapter.notifyItemInserted(0);
            profileFeedRecyclerView.smoothScrollToPosition(0);
        }
    }

    public void refreshFeed() {
        if (profileFeedAdapter != null) {
            profileFeedAdapter.notifyDataSetChanged();
        }
    }
}