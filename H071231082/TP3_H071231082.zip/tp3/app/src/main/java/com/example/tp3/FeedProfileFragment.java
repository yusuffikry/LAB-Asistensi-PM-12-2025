package com.example.tp3;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class FeedProfileFragment extends Fragment {
    private static final String ARG_IMAGE = "image";
    private static final String ARG_CAPTION = "caption";

    private String imageName;
    private String caption;
    private ProfileFeedAdapter profileFeedAdapter;

    public static FeedProfileFragment newInstance(String imageName, String caption) {
        FeedProfileFragment fragment = new FeedProfileFragment();
        Bundle args = new Bundle();
        args.putString(ARG_IMAGE, imageName);
        args.putString(ARG_CAPTION, caption);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            imageName = getArguments().getString(ARG_IMAGE);
            caption = getArguments().getString(ARG_CAPTION);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_feed_profile, container, false);

        ImageView content = view.findViewById(R.id.content);
        TextView captionText = view.findViewById(R.id.caption);
        CircleImageView pfp = view.findViewById(R.id.pfp);

        pfp.setImageResource(R.drawable.profile);

        // Check if imageName is null
        if (imageName != null && !imageName.isEmpty()) {
            int resId = getResources().getIdentifier(
                    imageName,
                    "drawable",
                    requireContext().getPackageName()
            );
            if (resId != 0) {
                content.setImageResource(resId);
            } else {
                content.setImageResource(R.drawable.img1); // Fallback image
            }
        } else {
            content.setImageResource(R.drawable.img1); // Fallback image
        }

        // Set caption
        captionText.setText(caption != null ? caption : "No caption provided");

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        // Refresh profile feed data
        if (profileFeedAdapter != null) {
            List<ProfileFeedItem> updatedProfileFeed = DataDummy.generateProfileFeed();
            profileFeedAdapter.updateProfileFeedItems(updatedProfileFeed);
        }
    }
}