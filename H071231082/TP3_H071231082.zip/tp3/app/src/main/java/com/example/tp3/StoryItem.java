package com.example.tp3;

import java.io.Serializable;

public class StoryItem implements Serializable {
    private String username;
    private String imageUrl;
    private boolean viewed;

    public StoryItem(String username, String imageUrl, boolean viewed) {
        this.username = username;
        this.imageUrl = imageUrl;
        this.viewed = viewed;
    }

    // Getter methods
    public String getUsername() { return username; }
    public String getImageUrl() { return imageUrl; }
    public boolean isViewed() { return viewed; }

    // Setter for viewed status
    public void setViewed(boolean viewed) { this.viewed = viewed; }
}