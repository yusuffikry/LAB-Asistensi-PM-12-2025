public class Response{

	@SerializedName("gender")
	private String gender;

	@SerializedName("species")
	private String species;

	@SerializedName("origin")
	private Origin origin;

	@SerializedName("name")
	private String name;

	@SerializedName("id")
	private int id;

	@SerializedName("type")
	private String type;

	@SerializedName("status")
	private String status;

	public String getGender(){
		return gender;
	}

	public String getSpecies(){
		return species;
	}

	public Origin getOrigin(){
		return origin;
	}

	public String getName(){
		return name;
	}

	public int getId(){
		return id;
	}

	public String getType(){
		return type;
	}

	public String getStatus(){
		return status;
	}
}
