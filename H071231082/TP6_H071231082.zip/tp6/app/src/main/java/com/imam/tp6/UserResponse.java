package com.imam.tp6;

import java.util.List;

public class UserResponse {
    private List<User> results;

    public List<User> getResults() {
        return results;
    }

    public void setResults(List<User> data) {
        this.results = data;
    }
}
