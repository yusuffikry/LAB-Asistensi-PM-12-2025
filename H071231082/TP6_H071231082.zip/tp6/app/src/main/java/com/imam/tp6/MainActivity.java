package com.imam.tp6;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.imam.tp6.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private UserAdapter adapter;
    private ApiService apiService;
    AtomicInteger page = new AtomicInteger(1);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        apiService = RetrofitClient.getClient().create(ApiService.class);
        binding.rvChar.setHasFixedSize(true);
        binding.rvChar.setLayoutManager(new LinearLayoutManager(this));
        adapter = new UserAdapter(new ArrayList<>());
        binding.rvChar.setAdapter(adapter);

        loadUsers(page.get());
        binding.loadBtn.setOnClickListener(v -> {
            binding.failedText.setVisibility(View.GONE);
            binding.progressBar.setVisibility(View.VISIBLE);
            page.getAndIncrement();
            loadUsers(page.get());
        });

    }

    public void loadUsers(int page) {
        Call<UserResponse> call = apiService.getUsers(page);
        binding.loadBtn.setVisibility(View.VISIBLE);

        call.enqueue(new Callback<UserResponse>() {
            @Override
            public void onResponse(Call<UserResponse> call, Response<UserResponse> response) {
                if (response.isSuccessful()) {
                    List<User> users = response.body().getResults();
                    binding.progressBar.setVisibility(View.GONE);
                    errorText("Failed to Fetch Data");
                    adapter.addUsers(users);
                }
            }

            @Override
            public void onFailure(Call<UserResponse> call, Throwable t) {
                binding.progressBar.setVisibility(View.GONE);
                binding.failedText.setVisibility(View.VISIBLE);
                errorText("No Internet Connection");
            }
        });
    }
    public void errorText(String message) {
        ((TextView) binding.failedText.findViewById(R.id.failedText)).setText(message);
    }
}