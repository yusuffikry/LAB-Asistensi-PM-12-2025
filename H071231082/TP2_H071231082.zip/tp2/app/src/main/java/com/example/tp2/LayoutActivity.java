package com.example.tp2;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class LayoutActivity extends AppCompatActivity {

    private ImageView profileimg, backBtn;
    private TextView tvProfile;
    private EditText etName, etEmail, etPhone;
    private CardView saveBtn;
    private Uri imageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_layout);
        View rootView = getWindow().getDecorView().findViewById(android.R.id.content);
        ViewCompat.setOnApplyWindowInsetsListener(rootView, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        backBtn = findViewById(R.id.backBtn);
        profileimg = findViewById(R.id.profileimg);
        tvProfile = findViewById(R.id.tvProfile);
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        saveBtn = findViewById(R.id.saveBtn);

        tvProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bukagaleri = new Intent(Intent.ACTION_GET_CONTENT);
                bukagaleri.setType("image/*");
                openGallery.launch(Intent.createChooser(bukagaleri, "Choose a picture"));
            }
        });

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nama = "";
                String email = "";
                String phone = "";

                if (etName.getText() != null) {
                    nama = etName.getText().toString();
                }

                if (etEmail.getText() != null) {
                    email = etEmail.getText().toString();
                }

                if (etPhone.getText() != null) {
                    phone = etPhone.getText().toString();
                }

                String imageUriString = "";
                if (imageUri != null) {
                    imageUriString = imageUri.toString();
                }

                User user = new User(nama, email, phone, imageUriString);

                Intent intent = new Intent(LayoutActivity.this, MainActivity.class);

                intent.putExtra("USER_DATA", user);

                startActivity(intent);
            }
        });
    }

    ActivityResultLauncher<Intent> openGallery = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            imageUri = data.getData();
                            profileimg.setImageURI(imageUri);
                        }
                    }
                }
            }
    );
}