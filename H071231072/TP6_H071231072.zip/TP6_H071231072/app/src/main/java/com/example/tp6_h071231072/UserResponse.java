package com.example.tp6_h071231072;

import java.util.List;

public class UserResponse {
    private Info info;
    private List<User> results;

    public Info getInfo() {
        return info;
    }

    public List<User> getResults() {
        return results;
    }
}
