package com.example.tp6_h071231072;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;


public interface ApiService {
    @GET("character")
    Call<UserResponse> getCharacters(@Query("page") int page);

    // Ubah nama method dan tipe parameter supaya sesuai DetailActivity
    @GET("character/{id}")
    Call<User> getUserDetail(@Path("id") int id);
    // gunakan String agar cocok dengan userId yang di-passing
}
