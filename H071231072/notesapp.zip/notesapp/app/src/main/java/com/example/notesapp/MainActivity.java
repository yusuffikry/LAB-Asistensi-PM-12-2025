package com.example.notesapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements NoteAdapter.OnNoteClickListener {
    private RecyclerView recyclerView;
    private NoteAdapter adapter;
    private DatabaseHelper dbHelper;
    private List<Note> noteList;
    private FloatingActionButton fabAdd;
    private EditText etSearch;
    private TextView tvNoData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupRecyclerView();
        setupSearch();
        loadNotes();
    }

    private void initViews() {
        recyclerView = findViewById(R.id.recycler_view);
        fabAdd = findViewById(R.id.fab_add);
        etSearch = findViewById(R.id.et_search);
        tvNoData = findViewById(R.id.tv_no_data);
//        Membuat instance DatabaseHelper
        dbHelper = new DatabaseHelper(this);
        noteList = new ArrayList<>();

        fabAdd.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddEditNoteActivity.class);
            startActivity(intent);
        });
    }

    private void setupRecyclerView() {
        adapter = new NoteAdapter(this, noteList);
        adapter.setOnNoteClickListener(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    private void setupSearch() {
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                performSearch(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void performSearch(String query) {
        if (query.trim().isEmpty()) {
            loadNotes();
        } else {
            List<Note> searchResults = dbHelper.searchNotes(query.trim());
            updateUI(searchResults);
        }
    }

    private void loadNotes() {
        noteList = dbHelper.getAllNotes();
        updateUI(noteList);
    }

    private void updateUI(List<Note> notes) {
        if (notes.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            tvNoData.setVisibility(View.VISIBLE);
            tvNoData.setText("No data");
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            tvNoData.setVisibility(View.GONE);
            adapter.updateList(notes);
        }
    }

    @Override
    public void onNoteClick(Note note) {
        Intent intent = new Intent(this, AddEditNoteActivity.class);
        intent.putExtra("note_id", note.getId());
        intent.putExtra("is_edit", true);
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Clear search when returning to main activity
        etSearch.setText("");
        loadNotes();
    }
}