package com.example.notesapp;

import android.app.AlertDialog;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class AddEditNoteActivity extends AppCompatActivity {
    private EditText etTitle, etDescription;
    private Button btnSubmit;
    private ImageButton btnBack, btnDelete;
    private TextView toolbarTitle;
    private DatabaseHelper dbHelper;
    private boolean isEditMode = false;
    private int noteId;
    private Note currentNote;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_note);

        initViews();
        setupToolbar();
        checkEditMode();
        setupClickListeners();
    }

    private void initViews() {
        etTitle = findViewById(R.id.et_title);
        etDescription = findViewById(R.id.et_description);
        btnSubmit = findViewById(R.id.btnSubmit);
        btnBack = findViewById(R.id.btn_back);
        btnDelete = findViewById(R.id.btnDelete);
        toolbarTitle = findViewById(R.id.toolbar_title);
        dbHelper = new DatabaseHelper(this);
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.topbar);
        // Kita akan handle sendiri

        // Tambahkan padding top untuk status bar jika diperlukan
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            int statusBarHeight = 0;
            int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
            if (resourceId > 0) {
                statusBarHeight = getResources().getDimensionPixelSize(resourceId);
            }
            toolbar.setPadding(0, statusBarHeight, 0, 0);
        }
    }

    private void checkEditMode() {
        isEditMode = getIntent().getBooleanExtra("is_edit", false);

        if (isEditMode) {
            noteId = getIntent().getIntExtra("note_id", -1);
            toolbarTitle.setText("Ubah");
            btnSubmit.setText("UPDATE");
            btnDelete.setVisibility(View.VISIBLE); // Tampilkan tombol delete
            loadNoteData();
        } else {
            toolbarTitle.setText("Tambah");
            btnSubmit.setText("SUBMIT");
            btnDelete.setVisibility(View.GONE); // Sembunyikan tombol delete
        }
    }

    private void loadNoteData() {
        currentNote = dbHelper.getNote(noteId);
        if (currentNote != null) {
            etTitle.setText(currentNote.getTitle());
            etDescription.setText(currentNote.getDescription());
        }
    }

    private void setupClickListeners() {
        // Back button click listener
        btnBack.setOnClickListener(v -> onBackPressed());

        // Delete button click listener
        btnDelete.setOnClickListener(v -> showDeleteConfirmationDialog());

        // Submit button click listener
        btnSubmit.setOnClickListener(v -> {
            String title = etTitle.getText().toString().trim();
            String description = etDescription.getText().toString().trim();

            if (title.isEmpty()) {
                etTitle.setError("title cannot be empty");
                etTitle.requestFocus();
                return;
            }

            if (isEditMode) {
                updateNote(title, description);
            } else {
                addNote(title, description);
            }
        });
    }

    private void addNote(String title, String description) {
        long result = dbHelper.addNote(title, description);
        if (result != -1) {
            Toast.makeText(this, "Note added successfully", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to add note", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateNote(String title, String description) {
        int result = dbHelper.updateNote(noteId, title, description);
        if (result > 0) {
            Toast.makeText(this, "Note updated successfully", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to update note", Toast.LENGTH_SHORT).show();
        }
    }

    private void showDeleteConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Note");
        builder.setMessage("Apakah anda yakin ingin menghapus item ini?");
        builder.setPositiveButton("YA", (dialog, which) -> {
            try {
                dbHelper.deleteNote(noteId);
                Toast.makeText(this, "Note deleted successfully", Toast.LENGTH_SHORT).show();
                finish();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to delete note", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("TIDAK", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    @Override
    public void onBackPressed() {
        String title = etTitle.getText().toString().trim();
        String description = etDescription.getText().toString().trim();

        // Check jika ada sa ubah
        boolean hasChanges = false;
        if (isEditMode) {
            hasChanges = currentNote != null &&
                    (!title.equals(currentNote.getTitle()) ||
                            !description.equals(currentNote.getDescription()));
        } else {
            hasChanges = !title.isEmpty() || !description.isEmpty();
        }

        if (hasChanges) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Batal");
            builder.setMessage("Apakah anda ingin membatalkan perubahan pada form?");
            builder.setPositiveButton("YA", (dialog, which) -> super.onBackPressed());
            builder.setNegativeButton("TIDAK", (dialog, which) -> dialog.dismiss());
            builder.show();
        } else {
            super.onBackPressed();
        }
    }
}