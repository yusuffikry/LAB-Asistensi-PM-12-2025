package com.example.libraryapp_h071231072;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.SearchView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HomeFragment extends Fragment {

    private RecyclerView recyclerView;
    private BookAdapter bookAdapter;
    private List<Book> bookList;
    private SearchView searchView;
    private ProgressBar progressBar;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewBooks);
        searchView = view.findViewById(R.id.searchViewBooks);
        progressBar = view.findViewById(R.id.progressBarHome); // Pastikan ID

        bookList = new ArrayList<>(BookData.getBooks());
        Collections.reverse(bookList); // Urutan terbaru ke atas

        bookAdapter = new BookAdapter(requireContext(), bookList);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        recyclerView.setAdapter(bookAdapter);

        // Filter judul dengan background thread + delay
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                bookAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                progressBar.setVisibility(View.VISIBLE);
                recyclerView.setVisibility(View.GONE);

                executor.execute(() -> {
                    try {
                        Thread.sleep(3000); // Delay 3 detik
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    requireActivity().runOnUiThread(() -> {
                        bookAdapter.getFilter().filter(newText);
                        progressBar.setVisibility(View.GONE);
                        recyclerView.setVisibility(View.VISIBLE);
                    });
                });
                return false;
            }
        });

        return view;
    }
}
