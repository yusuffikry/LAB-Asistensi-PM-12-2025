package com.example.libraryapp_h071231072;

import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class DetailActivity extends AppCompatActivity {

    private static final String TAG = "DetailActivity";
    private boolean liked = false;
    private Button likeButton;
    private int bookPosition = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_detail);
            Log.d(TAG, "DetailActivity started");

            // Enable back button in action bar
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setTitle("Book Detail");
            }

            // Pastikan intent hadir
            if (getIntent() == null) {
                Log.e(TAG, "Intent is null");
                Toast.makeText(this, "Error: Missing book data", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }

            // Inisialisasi views
            TextView title = findViewById(R.id.detailTitle);
            TextView author = findViewById(R.id.detailAuthor);
            TextView year = findViewById(R.id.detailYear);
            TextView blurb = findViewById(R.id.detailBlurb);
            ImageView cover = findViewById(R.id.detailCover);
            likeButton = findViewById(R.id.btnLike);

            // Verifikasi semua view ditemukan
            if (title == null || author == null || year == null ||
                    blurb == null || cover == null || likeButton == null) {
                Log.e(TAG, "One or more views not found");
                Toast.makeText(this, "Error loading UI components", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }

            // Ambil data dari intent dengan pengecekan keamanan
            bookPosition = getIntent().getIntExtra("book_position", -1);
            String bookTitle = getIntent().getStringExtra("title");
            String bookAuthor = getIntent().getStringExtra("author");
            int bookYear = getIntent().getIntExtra("year", 0);
            String bookBlurb = getIntent().getStringExtra("blurb");
            liked = getIntent().getBooleanExtra("liked", false);

            Log.d(TAG, "Book position received: " + bookPosition);
            Log.d(TAG, "Book title received: " + bookTitle);

            // Pastikan posisi buku valid
            if (bookPosition < 0) {
                Log.e(TAG, "Invalid book position: " + bookPosition);
                // Tetap lanjutkan tampilan, tetapi jangan update data
            }

            // Set data ke views dengan null checks
            title.setText(bookTitle != null ? bookTitle : "Unknown Title");
            author.setText(bookAuthor != null ? bookAuthor : "Unknown Author");
            year.setText(String.valueOf(bookYear));
            blurb.setText(bookBlurb != null ? bookBlurb : "No description available");

            // Handle image - either from URI or resource
            String coverUriString = getIntent().getStringExtra("coverUri");
            int bookCover = getIntent().getIntExtra("cover", R.drawable.ic_book);

            try {
                if (coverUriString != null && !coverUriString.isEmpty()) {
                    Uri coverUri = Uri.parse(coverUriString);
                    cover.setImageURI(coverUri);

                    // Check if image loaded successfully
                    if (cover.getDrawable() == null) {
                        Log.w(TAG, "Failed to load image from URI, using default");
                        cover.setImageResource(R.drawable.ic_book);
                    }
                } else {
                    // Use the resource ID
                    cover.setImageResource(bookCover);
                }
            } catch (Exception e) {
                Log.e(TAG, "Error setting image: " + e.getMessage());
                cover.setImageResource(R.drawable.ic_book);
            }

            updateLikeButton();

            // Set up like button click listener
            likeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    liked = !liked;
                    updateLikeButton();

                    // Verifikasi dan update status favorit buku
                    boolean updateSuccess = updateBookLikedStatus(bookPosition, liked);

                    if (updateSuccess) {
                        Toast.makeText(DetailActivity.this,
                                liked ? "Ditambahkan ke Favorit" : "Dihapus dari Favorit",
                                Toast.LENGTH_SHORT).show();
                    } else {
                        // Jika gagal mengupdate data tetapi UI sudah berubah, jangan tampilkan pesan error
                        // untuk menghindari kebingungan. Pencatatan sudah dilakukan di log.
                    }
                }
            });

        } catch (Exception e) {
            Log.e(TAG, "Fatal error in onCreate: " + e.getMessage(), e);
            Toast.makeText(this, "Error loading book details", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    /**
     * Method terpisah untuk mengupdate status "liked" di BookData
     * Return true jika berhasil, false jika gagal
     */
    private boolean updateBookLikedStatus(int position, boolean likeStatus) {
        if (position < 0) {
            Log.e(TAG, "Cannot update like status: Invalid position " + position);
            return false;
        }

        try {
            List<Book> books = BookData.getBooks();
            if (books == null) {
                Log.e(TAG, "BookData.getBooks() returned null");
                return false;
            }

            if (position >= books.size()) {
                Log.e(TAG, "Position out of bounds: " + position + " (size: " + books.size() + ")");
                return false;
            }

            Book book = books.get(position);
            if (book == null) {
                Log.e(TAG, "Book at position " + position + " is null");
                return false;
            }

            book.setLiked(likeStatus);
            Log.d(TAG, "Updated like status for " + book.getTitle() + " to " + likeStatus);
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Error updating like status: " + e.getMessage(), e);
            return false;
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void updateLikeButton() {
        if (likeButton != null) {
            likeButton.setText(liked ? "Unlike" : "Like");
        }
    }
}