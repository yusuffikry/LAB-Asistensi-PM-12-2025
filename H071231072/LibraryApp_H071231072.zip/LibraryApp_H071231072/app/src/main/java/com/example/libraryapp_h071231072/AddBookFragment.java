package com.example.libraryapp_h071231072;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class AddBookFragment extends Fragment {

    private EditText etTitle, etAuthor, etYear, etBlurb;
    private ImageView imageCover;
    private Button btnAddBook;
    private Uri imageUri;

    private static final int PICK_IMAGE = 1;

    // Activity Result Launcher sebagai pengganti startActivityForResult
    private final ActivityResultLauncher<Intent> galleryLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    imageUri = result.getData().getData();
                    imageCover.setImageURI(imageUri);
                }
            });

    public AddBookFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_book, container, false);

        etTitle = view.findViewById(R.id.etTitle);
        etAuthor = view.findViewById(R.id.etAuthor);
        etYear = view.findViewById(R.id.etYear);
        etBlurb = view.findViewById(R.id.etBlurb);
        imageCover = view.findViewById(R.id.imageCover);
        btnAddBook = view.findViewById(R.id.btnAddBook);

        imageCover.setOnClickListener(v -> openGallery());

        btnAddBook.setOnClickListener(v -> {
            String title = etTitle.getText().toString();
            String author = etAuthor.getText().toString();
            String year = etYear.getText().toString();
            String blurb = etBlurb.getText().toString();

            if (!title.isEmpty() && !author.isEmpty() && !year.isEmpty()) {
                Book newBook = new Book(title, author, Integer.parseInt(year), blurb,
                        (imageUri != null) ? imageUri.toString() : "", false);
                BookData.getBooks().add(0, newBook); // Add at the top
                Toast.makeText(getContext(), "Book Added!", Toast.LENGTH_SHORT).show();
                clearForm();
            } else {
                Toast.makeText(getContext(), "Fill all fields", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        galleryLauncher.launch(intent);
    }

    private void clearForm() {
        etTitle.setText("");
        etAuthor.setText("");
        etYear.setText("");
        etBlurb.setText("");
        imageCover.setImageResource(R.drawable.ic_book); // Placeholder image
        imageUri = null;
    }
}
