package com.example.libraryapp_h071231072;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FavoritesFragment extends Fragment {

    private RecyclerView recyclerView;
    private BookAdapter adapter;
    private List<Book> favoriteBooks = new ArrayList<>();
    private ProgressBar progressBar;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public FavoritesFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favorites, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewFavorites);
        progressBar = view.findViewById(R.id.progressBarFavorites);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new BookAdapter(getContext(), favoriteBooks);
        recyclerView.setAdapter(adapter);

        loadFavorites();

        return view;
    }

    private void loadFavorites() {
        progressBar.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.GONE);

        executor.execute(() -> {
            try {
                Thread.sleep(3000); // Simulasi delay 3 detik
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            List<Book> filteredBooks = new ArrayList<>();
            for (Book book : BookData.getBooks()) {
                if (book.isLiked()) {
                    filteredBooks.add(book);
                }
            }

            requireActivity().runOnUiThread(() -> {
                favoriteBooks.clear();
                favoriteBooks.addAll(filteredBooks);
                adapter.notifyDataSetChanged();

                progressBar.setVisibility(View.GONE);
                recyclerView.setVisibility(View.VISIBLE);
            });
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        loadFavorites(); // Refresh when returning to fragment
    }
}
