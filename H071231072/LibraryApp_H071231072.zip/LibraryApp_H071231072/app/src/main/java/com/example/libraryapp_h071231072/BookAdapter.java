package com.example.libraryapp_h071231072;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.BookViewHolder> implements Filterable {
    private static final String TAG = "BookAdapter";
    private Context context;
    private List<Book> bookList;
    private List<Book> bookListFull;

    public BookAdapter(Context context, List<Book> bookList) {
        this.context = context;
        this.bookList = bookList;
        this.bookListFull = new ArrayList<>(bookList);
    }

    @NonNull
    @Override
    public BookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        try {
            View view = LayoutInflater.from(context).inflate(R.layout.item_book, parent, false);
            return new BookViewHolder(view);
        } catch (Exception e) {
            Log.e(TAG, "Error creating view holder: " + e.getMessage());
            // Fallback untuk mencegah crash
            View fallbackView = new View(context);
            return new BookViewHolder(fallbackView);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull BookViewHolder holder, int position) {
        try {
            Book book = bookList.get(position);

            // Pastikan view references tidak null
            if (holder.title != null) {
                holder.title.setText(book.getTitle());
            }

            if (holder.author != null) {
                holder.author.setText(book.getAuthor());
            }

            // Set image dari URI atau resource ID
            if (holder.cover != null) {
                if (book.hasCustomCover()) {
                    try {
                        Uri coverUri = Uri.parse(book.getCoverUri());
                        holder.cover.setImageURI(coverUri);

                        // Jika gambar gagal dimuat, gunakan fallback
                        if (holder.cover.getDrawable() == null) {
                            holder.cover.setImageResource(R.drawable.ic_book);
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error loading cover URI: " + e.getMessage());
                        holder.cover.setImageResource(R.drawable.ic_book);
                    }
                } else {
                    holder.cover.setImageResource(book.getCoverResId());
                }
            }

            // Simpan posisi final untuk digunakan dalam listener
            final int bookPosition = position;

            holder.itemView.setOnClickListener(v -> {
                try {
                    Intent intent = new Intent(context, DetailActivity.class);
                    intent.putExtra("title", book.getTitle());
                    intent.putExtra("author", book.getAuthor());
                    intent.putExtra("year", book.getYear());
                    intent.putExtra("blurb", book.getBlurb());

                    if (book.hasCustomCover()) {
                        intent.putExtra("coverUri", book.getCoverUri());
                    } else {
                        intent.putExtra("cover", book.getCoverResId());
                    }

                    intent.putExtra("liked", book.isLiked());
                    // Gunakan fixed position yang disimpan sebelumnya, bukan getAdapterPosition()
                    intent.putExtra("book_position", bookPosition);

                    // Tambahkan log untuk debugging
                    Log.d(TAG, "Starting DetailActivity for book: " + book.getTitle() + " at position: " + bookPosition);

                    context.startActivity(intent);
                } catch (Exception e) {
                    Log.e(TAG, "Error starting DetailActivity: " + e.getMessage(), e);
                    Toast.makeText(context, "Gagal membuka detail buku", Toast.LENGTH_SHORT).show();
                }
            });

        } catch (Exception e) {
            Log.e(TAG, "Error binding view holder at position " + position + ": " + e.getMessage());
        }
    }

    @Override
    public int getItemCount() {
        return bookList != null ? bookList.size() : 0;
    }

    @Override
    public Filter getFilter() {
        return bookFilter;
    }

    private Filter bookFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<Book> filteredList = new ArrayList<>();

            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(bookListFull);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();

                for (Book book : bookListFull) {
                    if (book.getTitle().toLowerCase().contains(filterPattern)) {
                        filteredList.add(book);
                    }
                }
            }

            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            bookList.clear();
            if (results.values != null) {
                bookList.addAll((List<Book>) results.values);
            }
            notifyDataSetChanged();
        }
    };

    public static class BookViewHolder extends RecyclerView.ViewHolder {
        TextView title, author;
        ImageView cover;

        public BookViewHolder(@NonNull View itemView) {
            super(itemView);
            try {
                title = itemView.findViewById(R.id.textTitle);
                author = itemView.findViewById(R.id.textAuthor);
                cover = itemView.findViewById(R.id.imageCover);
            } catch (Exception e) {
                Log.e(TAG, "Error finding views in view holder: " + e.getMessage());
            }
        }
    }
}