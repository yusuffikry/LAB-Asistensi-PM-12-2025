package com.example.libraryapp_h071231072;

import java.util.ArrayList;
import java.util.List;

public class BookData {
    private static List<Book> books = new ArrayList<>();

    public static List<Book> getBooks() {
        if (books.isEmpty()) {
            books.add(new Book("Clean Code", "Robert C. Martin", 2008, "Buku tentang praktik menulis kode yang bersih dan dapat dibaca.", R.drawable.clean_code, false));
            books.add(new Book("The Pragmatic Programmer", "Andy Hunt", 1999, "Tips praktis untuk menjadi programmer profesional.", R.drawable.pragmatic_programmer, false));
            books.add(new Book("Design Patterns", "Erich Gamma", 1994, "Solusi untuk masalah umum dalam desain perangkat lunak.", R.drawable.design_patterns, false));
            books.add(new Book("Refactoring", "Martin Fowler", 1999, "Meningkatkan struktur internal perangkat lunak.", R.drawable.refactoring, false));
            books.add(new Book("Effective Java", "Joshua Bloch", 2008, "Panduan lengkap menulis kode Java yang efektif.", R.drawable.effective_java, false));
            // Tambahkan 10+ data lainnya sesuai ketentuan
            books.add(new Book("Android Programming", "Bill Phillips", 2015, "Panduan lengkap pengembangan aplikasi Android.", R.drawable.android_programming, false));
            books.add(new Book("Kotlin in Action", "Dmitry Jemerov", 2017, "Bahas Kotlin untuk aplikasi modern.", R.drawable.kotlin_in_action, false));
            books.add(new Book("Head First Java", "Kathy Sierra", 2005, "Pendekatan visual untuk belajar Java.", R.drawable.head_first_java, false));
            books.add(new Book("You Don't Know JS", "Kyle Simpson", 2014, "Seri mendalam tentang JavaScript.", R.drawable.ydkjs, false));
            books.add(new Book("Code Complete", "Steve McConnell", 2004, "Panduan menyeluruh tentang pengembangan perangkat lunak.", R.drawable.code_complete, false));
            books.add(new Book("Intro to Algorithms", "Thomas H. Cormen", 2009, "Buku algoritma klasik untuk semua level.", R.drawable.intro_algo, false));
            books.add(new Book("Cracking the Coding Interview", "Gayle Laakmann", 2015, "Persiapan wawancara coding.", R.drawable.cracking_interview, false));
            books.add(new Book("Data Structures and Algorithms", "Mark Allen Weiss", 2013, "Struktur data dan algoritma untuk pemula.", R.drawable.ds_algo, false));
            books.add(new Book("Deep Learning", "Ian Goodfellow", 2016, "Dasar dan praktik deep learning.", R.drawable.deep_learning, false));
            books.add(new Book("Artificial Intelligence", "Stuart Russell", 2010, "Dasar-dasar AI dan aplikasinya.", R.drawable.ai_modern, false));
        }
        return books;
    }
}