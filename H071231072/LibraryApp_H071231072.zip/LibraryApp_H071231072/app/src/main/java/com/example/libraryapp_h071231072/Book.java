package com.example.libraryapp_h071231072;

import android.net.Uri;

public class Book {
    private String title;
    private String author;
    private int year;
    private String blurb;
    private String coverUri;
    private int coverResId;
    private boolean isLiked;

    // Constructor for resource ID based books
    public Book(String title, String author, int year, String blurb, int coverResId, boolean isLiked) {
        this.title = title;
        this.author = author;
        this.year = year;
        this.blurb = blurb;
        this.coverResId = coverResId;
        this.coverUri = null;
        this.isLiked = isLiked;
    }

    // Constructor for URI based books (from gallery)
    public Book(String title, String author, int year, String blurb, String coverUri, boolean isLiked) {
        this.title = title;
        this.author = author;
        this.year = year;
        this.blurb = blurb;
        this.coverUri = coverUri;
        this.coverResId = 0;
        this.isLiked = isLiked;
    }

    // Getter dan Setter
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public int getYear() { return year; }
    public String getBlurb() { return blurb; }
    public int getCoverResId() { return coverResId; }
    public String getCoverUri() { return coverUri; }
    public boolean hasCustomCover() { return coverUri != null && !coverUri.isEmpty(); }
    public boolean isLiked() { return isLiked; }
    public void setLiked(boolean liked) { isLiked = liked; }
}