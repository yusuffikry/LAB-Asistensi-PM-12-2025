package com.example.tp3_h071231072_rafly;

import java.util.ArrayList;
import java.util.List;

public class StoryDataSource {


    public static List<Story>  generateDummyStoriesFeed() {
        List<Story> storyList = new ArrayList<>();

        User startup = UserDataSource.getUserByUsername("StartUpUnhas");
        User tiara = UserDataSource.getUserByUsername("tiaraandini");
        User lisa = UserDataSource.getUserByUsername("lalalalisa_m");
        User jennie = UserDataSource.getUserByUsername("jennierubyjane");
        User jisoo = UserDataSource.getUserByUsername("sooyaa__");
        User mahalini = UserDataSource.getUserByUsername("mahaliniraharja");
        User songkang = UserDataSource.getUserByUsername("songkang_b");



        storyList.add(new Story(startup, null, "2h", R.drawable.profile_startup));
        storyList.add(new Story(tiara, null, "3h", R.drawable.post_tiara1));
        storyList.add(new Story(lisa, null, "15h", R.drawable.profile_lisa));
        storyList.add(new Story(jennie,null, "7h", R.drawable.profile_jennie));
        storyList.add(new Story(jisoo, null, "1h", R.drawable.profile_jisoo));
        storyList.add(new Story(mahalini, null, "6h", R.drawable.profile_mahalini));
        storyList.add(new Story(songkang, null, "6h", R.drawable.profile_songkang));



        return storyList;
    }

    public static List<Story>  generateDummyStoryHighlights(String username) {
        List<Story> allHighlights = new ArrayList<>();

        User startup = UserDataSource.getUserByUsername("StartUpUnhas");
        User tiara = UserDataSource.getUserByUsername("tiaraandini");
        User lisa = UserDataSource.getUserByUsername("lalalalisa_m");
        User jennie = UserDataSource.getUserByUsername("jennierubyjane");
        User jisoo = UserDataSource.getUserByUsername("sooyaa__");
        User mahalini = UserDataSource.getUserByUsername("mahaliniraharja");
        User songkang = UserDataSource.getUserByUsername("songkang_b");

        allHighlights.add(new Story(startup,"kabinet visioner", "18 April", R.drawable.post_startup1));
        allHighlights.add(new Story(startup,"\uD83D\uDC99", "18 November 2024", R.drawable.post_startup2));
        allHighlights.add(new Story(startup,"\uD83D\uDDA4", "5 September 2024", R.drawable.post_startup3));
        allHighlights.add(new Story(startup,"Jerman", "25 Juni 2024", R.drawable.post_startup4));
        allHighlights.add(new Story(startup,"☀", "1 Juni 2024", R.drawable.post_startup5));
        allHighlights.add(new Story(startup,"ysl", "9 Maret 2024", R.drawable.post_startup6));
        allHighlights.add(new Story(startup,"ysl too", "2 November 2023", R.drawable.post_startup7));

//

        allHighlights.add(new Story(tiara, "1", "28 April 2023", R.drawable.post_tiara1));
        allHighlights.add(new Story(tiara, "2", "28 April 2023", R.drawable.post_tiara2));
        allHighlights.add(new Story(tiara, "3", "28 April 2023", R.drawable.post_tiara3));
        allHighlights.add(new Story(tiara, "4", "28 April 2023", R.drawable.post_tiara4));
        allHighlights.add(new Story(tiara, "5", "28 April 2023", R.drawable.post_tiara5));
        allHighlights.add(new Story(tiara, "6", "28 April 2023", R.drawable.post_tiara6));
        allHighlights.add(new Story(tiara, "choachella", "28 April 2023", R.drawable.post_tiara7));


//
//
        allHighlights.add(new Story(lisa, "\uD83C\uDF3B", "22 Agustus 2024", R.drawable.post_lisa1));
        allHighlights.add(new Story(lisa, "\uD83C\uDF7D\uFE0F", "7 Agustus 2024", R.drawable.post_lisa2));
        allHighlights.add(new Story(lisa, "circuit", "3 Agustus 2024", R.drawable.post_lisa3));
        allHighlights.add(new Story(lisa, "✨", "27 Mei 2024", R.drawable.post_lisa4));
        allHighlights.add(new Story(lisa, "Las Vegas", "25 November 2023", R.drawable.post_lisa5));
        allHighlights.add(new Story(lisa, "holiday", "24 Juli 2023", R.drawable.post_lisa6));
        allHighlights.add(new Story(lisa, "smile", "5 Januari 2025", R.drawable.post_lisa7));

//
//
        allHighlights.add(new Story(jennie, "\uD83D\uDDA4", "29 Januari 2025", R.drawable.post_jennie6));
        allHighlights.add(new Story(jennie, "\uD83C\uDDEB\uD83C\uDDF7 2", "29 Januari 2025", R.drawable.post_jennie1));
        allHighlights.add(new Story(jennie, "night", "28 Januari 2025", R.drawable.post_jennie2));
        allHighlights.add(new Story(jennie, "birthday", "15 March 2025", R.drawable.post_jennie3));
        allHighlights.add(new Story(jennie, "walk", "18 Januari 2025", R.drawable.post_jennie5));
        allHighlights.add(new Story(jennie, "adidas", "8 Juli 2024", R.drawable.post_jennie4));
        allHighlights.add(new Story(jennie, "\uD83C\uDDEB\uD83C\uDDF7 1", "16 September 2022", R.drawable.post_jennie7));

        allHighlights.add(new Story(jisoo, "dior", "22 November 2024", R.drawable.post_jisoo1));
        allHighlights.add(new Story(jisoo, "black", "15 September 2024", R.drawable.post_jisoo2));
        allHighlights.add(new Story(jisoo, "\uD83C\uDDEB\uD83C\uDDF7", "26 Juni 2024", R.drawable.post_jisoo3));
        allHighlights.add(new Story(jisoo, "✨", "28 Mei 2024", R.drawable.post_jisoo4));
        allHighlights.add(new Story(jisoo, "Cartier", "25 Februari 2024", R.drawable.post_jisoo5));
        allHighlights.add(new Story(jisoo, "\uD83C\uDDEC\uD83C\uDDE7", "25 November 2023", R.drawable.post_jisoo6));
        allHighlights.add(new Story(jisoo, "Shumon", "17 November 2023", R.drawable.post_jisoo7));

        allHighlights.add(new Story(mahalini, "lebaran", "17 November 2023", R.drawable.post_mahalini1));
        allHighlights.add(new Story(mahalini, "italia", "17 November 2023", R.drawable.post_mahalini2));
        allHighlights.add(new Story(mahalini, "\uD83E\uDD0D\n", "17 November 2023", R.drawable.post_mahalini3));
        allHighlights.add(new Story(mahalini, "\uD83C\uDF3C", "17 November 2023", R.drawable.post_mahalini4));
        allHighlights.add(new Story(mahalini, "\uD83C\uDF03", "17 November 2023", R.drawable.post_mahalini5));
        allHighlights.add(new Story(mahalini, "new year", "17 November 2023", R.drawable.post_mahalini6));
        allHighlights.add(new Story(mahalini, "paris", "17 November 2023", R.drawable.post_mahalini7));

        allHighlights.add(new Story(songkang, "orange", "14 Maret 2024", R.drawable.post_songkang1));
        allHighlights.add(new Story(songkang, "black", "8 Desember 2023", R.drawable.post_songkang2));
        allHighlights.add(new Story(songkang, "blue", "20 Maret 2023", R.drawable.post_songkang3));
        allHighlights.add(new Story(songkang, "hei!", "4 Maret 2023", R.drawable.post_songkang4));
        allHighlights.add(new Story(songkang, "sea", "4 November 2021", R.drawable.post_songkang5));
        allHighlights.add(new Story(songkang, "CARIN", "31 Agustus 2021", R.drawable.post_songkang6));
        allHighlights.add(new Story(songkang, "\uD83D\uDC99\n", "19 April 2021", R.drawable.post_songkang7));


        List<Story> filtered = new ArrayList<>();
        for (Story story : allHighlights) {
            if (story.getUser().getUsername().equals(username)) {
                filtered.add(story);
            }
        }
        return filtered;
    }
}