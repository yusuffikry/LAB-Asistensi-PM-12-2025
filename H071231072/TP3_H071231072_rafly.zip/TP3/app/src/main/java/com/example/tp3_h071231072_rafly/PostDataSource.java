package com.example.tp3_h071231072_rafly;

import java.util.ArrayList;
import java.util.List;

public class PostDataSource {
    public static List<Post> newPosts = new ArrayList<>();

    public static void addNewPost(Post post) {
        newPosts.add(0, post); // tambah di awal biar muncul di paling atas feed
    }

    public static List<Post> generateDummyPostsFeed() {
        List<Post> postsList = new ArrayList<>();
        User startup = UserDataSource.getUserByUsername("StartUpUnhas");
        User tiara = UserDataSource.getUserByUsername("tiaraandini");
        User lisa = UserDataSource.getUserByUsername("lalalalisa_m");
        User jennie = UserDataSource.getUserByUsername("jennierubyjane");
        User jisoo = UserDataSource.getUserByUsername("sooyaa__");
        User mahalini = UserDataSource.getUserByUsername("mahaliniraharja");
        User songkang = UserDataSource.getUserByUsername("songkang_b");

        postsList.addAll(newPosts);

        postsList.add(new Post(startup, "kabinet visioner", "18 April 2025", "4JT", "15,7rb", "60,4rb", R.drawable.post_startup1));
        postsList.add(new Post(tiara, "#BLACKPINK ##블랙핑크 #COACHELLA #WEEK2 #BEHIND #PHOTO #YG", "23 April 2023", "943rb", "468", "75", R.drawable.post_tiara1));
        postsList.add(new Post(lisa, "yellow", "3 Agustus 2024", "5,9JT", "31,2rb", "1234", R.drawable.post_lisa1));
        postsList.add(new Post(jennie, "\uD83C\uDDEB\uD83C\uDDF7", "29 Januari 2025", "4,2JT", "14,2rb", "43,1rb", R.drawable.post_jennie1));
        postsList.add(new Post(jisoo, "So honored to have been invited to the royal palace for a lovely banquet & to have received honorary MBEs! \uD83C\uDF80\n" + "Thank you for the unforgettable experience!\uD83C\uDDEC\uD83C\uDDE7", "25 November 2025", "4,1JT", "26rb", "42,7rb", R.drawable.post_jisoo1));
        postsList.add(new Post(mahalini, "mudiq\uD83C\uDDEC\uD83D\uDE9E\uD83D\uDE8D\uD83D\uDE9D\uD83D\uDE87\uD83D\uDE84\uD83D\uDE85\uD83D\uDCA8\uD83D\uDCA8\uD83D\uDCA8", "1 April", "1,7JT", "6.817", "9.669", R.drawable.post_mahalini1));
        postsList.add(new Post(songkang, "☺", "14 Maret 2024", "4,5JT", "43,5rb", "14,7rb", R.drawable.post_songkang1));

        return postsList;
    }

    public static List<Post> generateDummyPostProfilePage(String username) {
        List<Post> postsList = new ArrayList<>();
        User startup = UserDataSource.getUserByUsername("StartUpUnhas");
        User tiara = UserDataSource.getUserByUsername("tiaraandini");
        User lisa = UserDataSource.getUserByUsername("lalalalisa_m");
        User jennie = UserDataSource.getUserByUsername("jennierubyjane");
        User jisoo = UserDataSource.getUserByUsername("sooyaa__");
        User mahalini = UserDataSource.getUserByUsername("mahaliniraharja");
        User songkang = UserDataSource.getUserByUsername("songkang_b");

        // --- Daftar semua post
        postsList.add(new Post(startup, "Kabinet Visioner ◡̈", "18 April", "4JT", "15,7rb", "60,4rb", R.drawable.post_startup1));
        postsList.add(new Post(startup, "\uD83D\uDC99 @i_d \uD83D\uDC99", "18 November 2024", "3,8JT", "13,5rb", "60,4rb", R.drawable.post_startup2));
        postsList.add(new Post(tiara, "#Konser ##블랙핑크 #MAKASSAR", "28 April 2023", "943rb", "468", "75", R.drawable.post_tiara1));
        postsList.add(new Post(lisa, "\uD83C\uDF4B\uD83C\uDF3C\uD83D\uDC25", "22 Agustus 2024", "5,9JT", "31,2rb", "1234", R.drawable.post_lisa1));
        postsList.add(new Post(jennie, "\uD83C\uDDEB\uD83C\uDDF7", "29 Januari", "4,2JT", "14,2rb", "43,1rb", R.drawable.post_jennie1));
        postsList.add(new Post(jisoo, "@ellekorea @dior 과 함께 미리 크리스마스\uD83C\uDF84", "22 November 2024", "5,2JT", "34,8rb", "101rb", R.drawable.post_jisoo1));
        postsList.add(new Post(mahalini, "mudiq\uD83C\uDDEC\uD83D\uDE9E", "1 April", "1,7JT", "6.817", "9.669", R.drawable.post_mahalini1));
        postsList.add(new Post(songkang, "☺", "14 Maret 2024", "4,5JT", "43,5rb", "14,7rb", R.drawable.post_songkang1));

        // --- Tambahkan newPosts ke dalam daftar
        postsList.addAll(newPosts);

        // --- Filter berdasarkan username
        List<Post> filtered = new ArrayList<>();
        for (Post post : postsList) {
            if (post.getUser() != null && post.getUser().getUsername().equalsIgnoreCase(username)) {
                filtered.add(post);
            }
        }

        return filtered;
    }
}
