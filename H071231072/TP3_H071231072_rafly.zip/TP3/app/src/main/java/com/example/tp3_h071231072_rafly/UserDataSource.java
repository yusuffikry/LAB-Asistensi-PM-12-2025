package com.example.tp3_h071231072_rafly;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;

public class UserDataSource {
    private static List<User> userList = new ArrayList<>();

    public static List<User> getAllUsers(Context context) {
        if (userList.isEmpty()) {
            generateDummyUsers(context);
        }
        return userList;
    }

    public static void generateDummyUsers(Context context) {
        if (!userList.isEmpty()) return;

        userList.add(new User("StartUpUnhas", "UKM Start-Up Unhas", "83,7JT", "0", "organisasi", "Artis papan atas ini bos", "https://www.youtube.com/@roses_are_rosie", R.drawable.profile_startup));
        userList.add(new User("tiaraandini", "tiaraandini", "57,5JT", "5", "Girl ", "blackpink in your area", "https://www.youtube.com/@blackpink", R.drawable.post_tiara1));
        userList.add(new User("lalalalisa_m", "LISA", "105JT", "0", "Artis/Girl Group", "ALTER EGO", "https://www.youtube.com/@wearelloud", R.drawable.profile_lisa));
        userList.add(new User("jennierubyjane", "J", "87,1JT", "0", "Artis/Girl Group", "LIKE JENNIE", "https://www.youtube.com/@jennierubyjane", R.drawable.profile_jennie));
        userList.add(new User("sooyaa__", "JISSO\uD83E\uDE90", "79,8JT", "0", "Artis/Girl Group", "earthquake ", "https://www.youtube.com/@sooyaaa__", R.drawable.profile_jisoo));
        userList.add(new User("mahaliniraharja", "", "7,1JT", "2.180", "Artis/Penyanyi", "(+62) 81514566398 (@biondy_akbar )", "bfan.link/mencintaimu-5", R.drawable.profile_mahalini));
        userList.add(new User("songkang_b", "", "22JT", "0", "Aktor", "송강", "https://www.instagram.com/songkang_b", R.drawable.profile_songkang));


    }

    public static User getUserByUsername(String username) {
        for (User user : userList) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }
}