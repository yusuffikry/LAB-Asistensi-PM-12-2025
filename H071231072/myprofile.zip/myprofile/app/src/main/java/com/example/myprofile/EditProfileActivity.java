package com.example.myprofile;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class EditProfileActivity extends AppCompatActivity {

    EditText etName, etHeadline, etEducation, etLocation, etAbout;
    Button btnSave;
    ImageView ivProfilePic;
    ImageView btnChangeProfilePic;
    private Uri selectedImageUri;

    // untuk meluncurkan intent pemilihan gmbr dari galeri
    ActivityResultLauncher<Intent> pickImageLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);


        // Inisialisasi View
        etName = findViewById(R.id.etName);
        etHeadline = findViewById(R.id.etHeadline);
        etEducation = findViewById(R.id.etEducation);
        etLocation = findViewById(R.id.etLocation);
        etAbout = findViewById(R.id.etAbout);
        ivProfilePic = findViewById(R.id.ivProfilePic);
        btnChangeProfilePic = findViewById(R.id.btnChangeProfilePic);
        btnSave = findViewById(R.id.btnSave);

        // Ambil data dari Intent
        Intent intent = getIntent();
        etName.setText(intent.getStringExtra("name"));
        etHeadline.setText(intent.getStringExtra("headline"));
        etEducation.setText(intent.getStringExtra("education"));
        etLocation.setText(intent.getStringExtra("location"));
        etAbout.setText(intent.getStringExtra("about"));
        Uri imageUri = intent.getParcelableExtra("imageUri");
        if (imageUri != null) {
            selectedImageUri = imageUri;
            ivProfilePic.setImageURI(selectedImageUri);
        }

        // Untuk pilih gambar dari galeri
        pickImageLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        selectedImageUri = result.getData().getData();
                        ivProfilePic.setImageURI(selectedImageUri);
                    }
                });

        // Aksi klik tombol ubah foto
        btnChangeProfilePic.setOnClickListener(v -> {
            Intent galleryIntent = new Intent(Intent.ACTION_PICK);
            galleryIntent.setType("image/*");
            pickImageLauncher.launch(galleryIntent);
        });

        // Aksi klik tombol simpan
        btnSave.setOnClickListener(v -> {
            Intent resultIntent = new Intent();
            resultIntent.putExtra("name", etName.getText().toString());
            resultIntent.putExtra("headline", etHeadline.getText().toString());
            resultIntent.putExtra("education", etEducation.getText().toString());
            resultIntent.putExtra("location", etLocation.getText().toString());
            resultIntent.putExtra("about", etAbout.getText().toString());

            if (selectedImageUri != null) {
                resultIntent.putExtra("imageUri", selectedImageUri);
            }

            setResult(Activity.RESULT_OK, resultIntent);
            finish();
        });
    }
}
