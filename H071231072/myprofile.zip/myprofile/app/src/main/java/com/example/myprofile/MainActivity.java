package com.example.myprofile;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView tvName, tvHeadline, tvEducation, tvLocation, tvAbout;
    ImageView ivProfilePic, btnEditProfile;
    Uri profileImageUri;

    ActivityResultLauncher<Intent> editProfileLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi View
        tvName = findViewById(R.id.tvName);
        tvHeadline = findViewById(R.id.tvHeadline);
        tvEducation = findViewById(R.id.tvEducation);
        tvLocation = findViewById(R.id.tvLocation);
        tvAbout = findViewById(R.id.tvAbout);
        ivProfilePic = findViewById(R.id.ivProfilePic);
        btnEditProfile = findViewById(R.id.btnEditProfile); // Tombol/edit icon untuk masuk halaman edit

        // Inisialisasi launcher untuk menerima data dari EditProfileActivity
        editProfileLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        Intent data = result.getData();

                        tvName.setText(data.getStringExtra("name"));
                        tvHeadline.setText(data.getStringExtra("headline"));
                        tvEducation.setText(data.getStringExtra("education"));
                        tvLocation.setText(data.getStringExtra("location"));
                        tvAbout.setText(data.getStringExtra("about"));

                        Uri imageUri = data.getParcelableExtra("imageUri");
                        if (imageUri != null) {
                            profileImageUri = imageUri;
                            ivProfilePic.setImageURI(profileImageUri);
                        }
                    }
                });

        // Aksi klik edit
        btnEditProfile.setOnClickListener(v -> {

            Intent intent = new Intent(MainActivity.this, EditProfileActivity.class);
            // Kirim data saat ini untuk diedit
            intent.putExtra("name", tvName.getText().toString());
            intent.putExtra("headline", tvHeadline.getText().toString());
            intent.putExtra("education", tvEducation.getText().toString());
            intent.putExtra("location", tvLocation.getText().toString());
            intent.putExtra("about", tvAbout.getText().toString());

            intent.putExtra("imageUri", profileImageUri);

            editProfileLauncher.launch(intent);
        });
    }
}
